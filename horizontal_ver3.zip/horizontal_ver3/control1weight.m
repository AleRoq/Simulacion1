function [ws,wc,wt]=control1weight(fearFactor);
% Weight functions WC WS and WT for Unmanned vehicle system

%
ms=1.7;% 0.3;%1.5;    % guarantee overshot Mp < 6dB = 20*log10(2) 
wbs=0.23;%0.05;%0.23;
ee=1e-3;%1e-4
ki=1; % used to give more accurate adjustment to the cut-off frequency wbs
      % by default set it to 1
%           --------     WT Data    ------------
mt=1.3;%1.00;    % guarantee overshot Mp < 2dB = 20*log10(1.26)
wbt=4.1;%9.1;%4.1;
ee=1e-3;%1e-4

mc=10;% in dB = 20 log10 (mc)
wbc=20;%10
eec=1e-2; % -20dB/1e-1;

% Sliding ws and wt respect to the x axis
% fearFactor=0.1;
wbs=fearFactor*wbs;
wbt=fearFactor*wbt;

%           --------     WS     ------------
%

num1=conv([1/sqrt(ms) 10^(ki-1)*wbs],[1/sqrt(ms) 10^(ki-1)*wbs]);
den1=conv([1 10^(ki-1)*wbs*sqrt(ee)],[1 10^(ki-1)*wbs*sqrt(ee)]);
ws1=nd2sys(num1,den1);
num2=conv([1/sqrt(ms) 10^(ki-1)*wbs],[1/sqrt(ms) 10^(ki-1)*wbs]);
den2=conv([1 10^(ki-1)*wbs*sqrt(ee)],[1 10^(ki-1)*wbs*sqrt(ee)]);
ws2=nd2sys(num2,den2);
ws=daug(ws1,ws2);
%
%
%           --------     WT     ------------

num1=conv([1 wbt/sqrt(mt)],[1 wbt/sqrt(mt)]);
den1=conv([sqrt(ee) wbt],[sqrt(ee) wbt]);
%wt1=nd2sys([1 1/mt*wbt],[ee wbt]);
wt1=nd2sys(num1,den1);
num2=conv([1 wbt/sqrt(mt)],[1 wbt/sqrt(mt)]);
den2=conv([sqrt(ee) wbt],[sqrt(ee) wbt]);
wt2=nd2sys(num2,den2);
wt=daug(wt1,wt2);
%
%           --------     WC     ------------

wc=nd2sys([1 1/mc*wbc],[eec wbc]);
wc1=wc;
wc2=wc;
wc=daug(wc1,wc2);

%
%**************************************************************************
%                  ----    plot de WS  WC WT    -----
w=logspace(-4,6,100);
%
sv1s=sigma(ws,w,1); % option "1" is used to indicate the inverse
sv1t=sigma(wt,w,1);
sv1c=sigma(wc,w,1);

figure;
semilogx(w, 20*log10(sv1s),'b',w, 20*log10(sv1t),'m');
title('WS WT')
xlabel('rad/sec')
ylabel('dB')
grid
%AXIS([0.0001 1000000 -200 50])

figure;
semilogx(w, 20*log10(sv1s),'b',w, 20*log10(sv1t),'m',w, 20*log10(sv1c),'g');
title('WS WT WC')
xlabel('rad/sec')
ylabel('dB')
grid
%AXIS([0.0001 1000000 -200 50])

%}

%disp('Press Return to continue')
%pause
