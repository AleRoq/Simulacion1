% PID controller parameters for control2 project
% surge velocity controller
Pro1=131.84;%140;
Int1=229.71;%188;
% yaw angle controller
Pro2=47.04;%33;
Der2=61.14;%40;
