% PID controller parameters
% surge velocity controller
Pro1=50.73;
Int1=80.42;
Der1=151.77;
Nfilt1=3.66158701082739e-07;
% yaw angle controller
Pro2=26.82;
Int2=1e-8;
Der2=-0.0000451073360484306;
Nfilt2=5.11135875763505e-07;
