% surge 
Fu=767.4455*u*abs(u)+19.7802*u+0.0457 % forward
%Fu=308.5060*u*abs(u)+41.4510*u+0.3932 % reverse
% sway
Fv=
% heave
Fw=1706.5544*v*abs(v)-311.6376*v+29.1974 % forward (to seabed
%Fw= % negative (to sea surface)
% roll
Mp=
% pitch
Mq=
% yaw
Mr=83.9085*r*abs(r)+2.2687*r+0.3989  % anticlock-wise 
%Mr=104.2863*r*abs(r)+8.5552*r-1.5534 % clock-wise
% Thruster data model
Fthr= 11.297*vcc^2 −13.4388*vcc +5.1661 % forward
%Fthr= 7.2131*Vcc^2 −8.5807*Vcc  +3.2986 % reverse
