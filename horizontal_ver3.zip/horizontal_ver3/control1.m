% control1
close all;
clear all;
% load linear model
load dataout/ltiX.mat

% Analysis of the model
A=linear.a;
B=linear.b;
C=linear.c;
D=linear.d;

% Y=[u, v, r, apsi]' and U=[tau_u, tau_r]'
ap=[A(1:3,1:3) A(1:3,6);  
    A(6,1:3)   A(6,6)];
bp=[B(1:3,:);
    B(6,:)];
cp=[C(1:3,1:3) C(1:3,6);
    C(6,1:3)   C(6,6)];
dp=[D(1:3,:);
    D(6,:)];

% Y=[u, apsi]' and U=[tau_u, tau_r]'
ap=ap;
bp=bp;
cp=[cp(1,:);
    cp(4,:)];
dp=[dp(1,:);
    dp(4,:)];

olsys=ss(ap,bp,cp,dp); % open loop system
figure;
pzmap(olsys)
disp('Comment: see the poles and the transmission zeros')
%pause

% Controllability
%
cm = ctrb(ap,bp);  % Controllability matrix
rcm= rank(cm)      % Rank of the matrix
% compare with the length of ap
uncon=length(ap)-rcm

% Observability
%
om = obsv(ap,cp);  % Observability matrix
rom = rank(om)     % Rank of the matrix
unobs=length(ap)-rom

% Transfer Functions (tf) of the MIMO system
sys = zpk(ss(ap,bp,cp,dp))     % Zeros, Poles, and Gains from u_i to x_j
[Z,P,K]=zpkdata(sys)
% surge tf
num11=K(1,1).*poly(Z{1,1});
den11=poly(P{1,1});
% yaw angle tf
disp('The transfer function between "yaw angle" and "tau_r"')
num22=K(2,2).*poly(Z{2,2})
den22=poly(P{2,2})

sys1=tf(num11,den11)
sys2=tf(num22,den22)
% Warning to use "ssdata" 'cause there are many differents state space matrices
% to represent one dynamic system
z = tzero(ss(ap,bp,cp,dp))     % transmission zeros of Gp(s) open-loop
                               % (G(s) tem que ser m*m)
% Minimum Phase System: no zeros in RHP, or no time delays
pma = pole(ss(ap,bp,cp,dp))    % pólos de Gp(s)em malha aberta
% zdir1 = null([z(1)*eye(8)- ap  -bp; cp dp]) % direçao do Zero de transmissão z1
% zdir2 = null([z(2)*eye(8)- ap  -bp; cp dp]) % direçao do Zero de transmissão z2
%pause
[auvec,auval] = eig(ap)          % evec contains eigenvectors
w=logspace(-4,4,100);
%
sv = sigma(ss(ap, bp, cp, dp),w);
sv = 20*log10(sv);
figure;
semilogx(w, sv)
title('Open loop Bode') 
xlabel('rad/sec')
ylabel('dB')
grid

%**************************************************************************
%
%                Analises em DC do Sistema Submersivel
%
%dc =  cp*inv(-ap)*bp
%[udc,sdc,vdc] = svd(dc)
%**************************************************************************
%                           Escalonamento
%                        
d2r=pi/180;
r2d=180/pi;
su = diag( [1/200,1/(200*0.25)] );       % tau_u_max=300 [N] tau_r_max=100 [Nm]

sx = diag([1/1,1/0.5,1/(20*d2r),1/(160*d2r)]);  % mudança de escala

sy = diag([1/1,1/(160*d2r)]);

ap_s = sx*ap*inv(sx)
bp_s = sx*bp*inv(su)
cp_s = sy*cp*inv(sx)
dp_s = sy*dp*inv(su)

w=logspace(-4,4,100);
%
sv = sigma(ss(ap_s, bp_s, cp_s, dp_s),w);
sv = 20*log10(sv);
figure;
semilogx(w, sv)
title('Open loop Bode') 
xlabel('rad/sec')
ylabel('dB')
grid
pause
disp('Return to continue and Ctrl+C to escape')
g=pck(ap_s,bp_s,cp_s,dp_s);
%******************** Robust Control approach based on the LMI solve ***********
	fearFactor= 0.996;%0.53;%0.66;
	[ws,wc,wt]=control1weight(fearFactor);
	systemnames = 'g wt wc ws';
	inputvar='[ref(2);ucontrol(2)]';
	outputvar='[ws;wc;wt;ref-g]';
	input_to_g='[ucontrol]';
	input_to_wt='[g]';
	input_to_wc='[ucontrol]';
	input_to_ws='[ref-g]';
	sysoutname='pext';            % Extended Plant
	cleanupsysic='yes';
	sysic;
	%
	%
	nmeas=2;        % number of measured outputs
	ncon=2;         % number of control inputs
	gmin=0.001;
	gmax=10000000;
	tol=0.001;
	%[k,tzw,gsubopt]=hinfsyn(pext,nmeas,ncon,gmin,gmax,tol);
	%
	% Another alternative H-infinity solve for singular Plants
	r=[nmeas ncon]';
% uncomment if it uses RIC method (for singular plants)
%	[gsubopt,k,X1,X2,Y1,Y2,Preg] = hinfric(pext,r,gmin,gmax,tol);
% uncomment if it uses LMI classic method (for singular plants)
%	[gsubopt,k] = hinflmi(pext,r)
% uncomment if it uses LMI method
[a_pext,b_pext,c_pext,d_pext]=unpck(pext);
sys_pext=ss(a_pext,b_pext,c_pext,d_pext);
P1=minreal(sys_pext)
[K1,Nsc1,gamma(1),info]=hinfsyn(P1,nmeas,ncon,'method','lmi','Tolgam',1e-3)

%************************8 Analysis of the resutls *****************************
sysk=K1;
[ak1,bk1,ck1,dk1]=ssdata(sysk);
k=pck(ak1,bk1,ck1,dk1);
tzw=Nsc1;
gsubopt=gamma;
disp('End of Hinfsyn (ric or lmi)')
fprintf('The gamma suboptimal = %4.5f\n',gsubopt)
disp('Press Ctrl+C or Return')
pause
sysh=mmult(g,k);
[al,bl,cl,dl]=unpck(sysh);
[ak1,bk1,ck1,dk1]=unpck(k);

%***************** Closed loop analysis
%
clpoles = eig(al-bl*cl)           % Poles in closed loop
clsys=ss(al-bl*cl, bl, cl, 0*eye(2)); % closed loop system

figure;
pzmap(clsys)
clzeros=zero(clsys)
clpoles=pole(clsys)

% To see if there are zeros close to or superpositioned over poles
clzerosStr=num2str(clzeros)
clpolesStr=num2str(clpoles)
disp('see the pzmap and indentify the location of poles and zeros')
disp('and press Return to continue')
%pause
%
w=logspace(-3,3,100);
%
sensi=pck(al-bl*cl, bl, -cl, eye(2));
tsensi=pck(al-bl*cl, bl, cl, 0*eye(2));
%
sv = sigma(ss(al-bl*cl, bl, -cl, eye(2)),w);
sv = 20*log10(sv);
figure;
semilogx(w, sv)
%clear sv
title('Sensitivity')
grid
xlabel('Frequency (rad/s)')
ylabel('Singular Values (dB)')
%pause
sv = sigma(ss(al-bl*cl, bl, cl, 0*eye(2)),w);
sv = 20*log10(sv);
figure;
semilogx(w, sv)
%clear sv
title('Complementary Sensitivity T' )
grid
xlabel('Frequency (rad/s)')
ylabel('Singular Values (dB)')

%                  Plot the singular Values WsT and WtT
%
wssensi=mmult(ws,sensi);
wtsensi=mmult(wt,tsensi);

sv= sigma(wssensi,w);
figure;
semilogx(w,sv)
title('Ws*S' )
grid
xlabel('Frequency (rad/s)')
ylabel('Magnitude')
%pause 

sv= sigma(wtsensi,w);
figure;
semilogx(w,sv)
title('Wt*T' )
grid
xlabel('Frequency (rad/s)')
ylabel('Magnitude')
%pause
%******************** Step Response using 'step' command **********************
t=[0:1/100:100];
y=step(ss(al-bl*cl, bl, cl, 0*eye(2)),t);
figure;
plot(t,y(:,1,1),t,y(:,1,2))
figure;
plot(t,y(:,2,1),t,y(:,2,2))

%save dataout/control1Xhinf.mat ak1 bk1 ck1 dk1 K1 gamma ws wt wc ap bp cp dp sx sy su ap_s bp_s cp_s dp_s


