% analisys of linearized models
close all;
clear all;
% load linear model
load ltiX.mat

% Analysis of the model
A=linear.a;
B=linear.b;
C=linear.c;
D=linear.d;

% Y=[u, v, r, apsi]' and U=[tau_u, tau_r]'
ap=[A(1:3,1:3) A(1:3,6);  
    A(6,1:3)   A(6,6)];
bp=[B(1:3,:);
    B(6,:)];
cp=[C(1:3,1:3) C(1:3,6);
    C(6,1:3)   C(6,6)];
dp=[D(1:3,:);
    D(6,:)];

% Y=[u, apsi]' and U=[tau_u, tau_r]'
ap=ap;
bp=bp;
cp=[cp(1,:);
    cp(4,:)];
dp=[dp(1,:);
    dp(4,:)];

olsys=ss(ap,bp,cp,dp); % open loop system
figure;
pzmap(olsys)
disp('Comment: see the poles and the transmission zeros')
%pause

% Controllability
%
cm = ctrb(ap,bp);  % Controllability matrix
rcm= rank(cm)      % Rank of the matrix
% compare with the length of ap
uncon=length(ap)-rcm

% Observability
%
om = obsv(ap,cp);  % Observability matrix
rom = rank(om)     % Rank of the matrix
unobs=length(ap)-rom

% Transfer Functions (tf) of the MIMO system
sys = zpk(ss(ap,bp,cp,dp))     % Zeros, Poles, and Gains from u_i to x_j
[Z,P,K]=zpkdata(sys)
% surge tf
num11=K(1,1).*poly(Z{1,1});
den11=poly(P{1,1});
% yaw angle tf
disp('The transfer function between "yaw angle" and "tau_r"')
num22=K(2,2).*poly(Z{2,2})
den22=poly(P{2,2})

sys1=tf(num11,den11)
sys2=tf(num22,den22)
