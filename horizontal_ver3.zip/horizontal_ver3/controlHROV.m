function[Vdot]=HROV3DOF_H(V,tau)
% 3DOF of hybrid underwater ROV
%M vdot+C(v)v+D(v)v+g(n)=tau
%coefficients in International Systems
% V=[u v r]';



% Data
m=150;
Iz=19.5;% kg m^2;
xg=-0.013;
yg=0;

xudot=-157;
yvdot=-197;
nrdot=-8,5;
yrdot=0;
nvdot=0;

xuu=200;
yvv=200;
nrr=50;

MRB=[  m     0    -m*yg;
       0     m     m*xg;
     -m*yg  m*xg    Iz];

MA=[-xudot      0      0;
       0     -yvdot -yrdot;
       0     -nvdot -nrdot];
M=MRB+MA;
CV=[    0        0 yvdot*v+yrdot*r;
          0        0      m*u;
      m*(xg*r+v) -m*u      0];
DV=[xuu*abs(u)     0          0;
         0       yvv*abs(v)     0;
         0           0      nrr*abs(r)];
g=[0 0 0]';
% from M vdot+C(v)v+D(v)v+g(n)=tau
% 
Minv=inv(M);
Vdot=Minv*(-CV*V-DV*V-g+tau);
