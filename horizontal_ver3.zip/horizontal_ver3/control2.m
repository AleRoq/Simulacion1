% control2.m is a PID control approach for horizontal ROV model (free-flight mode)
% Here the whole linearized model is reduced to a Namoto model
close all;
clear all;
% load linear model
load dataout/ltiX.mat

% Analysis of the model
A=linear.a;
B=linear.b;
C=linear.c;
D=linear.d;

% Y=[u, v, r, apsi]' and U=[tau_u, tau_r]'
ap=[A(1:3,1:3) A(1:3,6);  
    A(6,1:3)   A(6,6)];
bp=[B(1:3,:);
    B(6,:)];
cp=[C(1:3,1:3) C(1:3,6);
    C(6,1:3)   C(6,6)];
dp=[D(1:3,:);
    D(6,:)];

% Y=[u, apsi]' and U=[tau_u, tau_r]'
ap=ap;
bp=bp;
cp=[cp(1,:);
    cp(4,:)];
dp=[dp(1,:);
    dp(4,:)];

olsys=ss(ap,bp,cp,dp); % open loop system
figure;
pzmap(olsys)
disp('Comment: see the poles and the transmission zeros')
%pause
%*******************************************************************************
% Here, the Namoto model is obtained
% states [v r], output [r], input [tau_r]
ap=ap(2:3,2:3);
bp=bp(2:3,:);
cp=[0 1];
dp=[0];

%             -1
% G(s)=C(sI-A)  B + D
%
sys = zpk(ss(ap,bp,cp,dp))     % Zeros, Poles, and Gains from u_i to x_j
[Z,P,K]=zpkdata(sys)
% yaw rate / tau_r transfer function 
num=K(2).*poly(Z{1,2});
den=poly(P{1,2});
sys1=tf(num,den)
% It gives:
% Transfer function:
%   0.02793 s + 0.01666
% -----------------------
% s^2 + 0.9155 s + 0.0785
%
% Transfer function:
%  0.02981 s + 0.449
% --------------------
% s^2 + 15.25 s + 2.77   

% According to the G. N. Roberts (2006), the Namoto model can be expressed as:
%    r           k(1+T3s)              kT3 (s+1/T3)
% ------- = ------------------ = -------------------------
%  tau_r      (1+T1s)(1+T2s)       T1T2 (s+1/T1)(s+1/T2)
%  
% A first-order approximation is given by:
%
%    r         k
% ------- = --------
%  tau_r     (1+Ts)
%
% where T=T1+T2-T3

T1=-1/P{1,2}(1); % p1=-1/T1
T2=-1/P{1,2}(2); % p2=-1/T2
T3=-1/Z{1,2}; % z1=-1/T3
k=K(2)*(T1*T2/T3); % K=k*T3/(T1T2)

% and

T=T1+T2-T3;
sys1Red=tf(k,[T 1])
% It gives
% Transfer function:
%   0.2123
% -----------
% 9.986 s + 1

% Plot figures to compare
figure;
bode(sys1Red);hold on
bode(sys1)
% PID controller design (FOSSEN approach) **************************************
%
% scaling the coefficients
U=0.5; % speed U=sqrt(u^2+v^2+w^2)
L=1000e-3; % L is the length of the vehicle
Ki=(L/U)*k;
Ti=(U/L)+T;
% if the PD controller is defined as:
% tau_r=(Ti/Ki)(L/U)^2(-kp e - kd e_dot)
% Therefore, the error dynamic is written as:
% ..                  .
% e  + (1/Ti(U/L)+kd) e + kp e   = 0
%
% ..                  .
% e  +    (2 wn zeta} e + wn^2 e = 0
%
% that can be compared as a second order system response coefficients, where:
%
zeta=0.7;
wn=0.5;% 1; %observe that 1/T = 0.18 rad/s
kp=wn^2;
kd=2*wn^2*zeta-1/Ti*(U/L);
% the above results gives: kp=33.5557 and kd=44.1534
% then, to implement and simulate responses of the controller system, go to the
% simulink file of these model
%
% PID controller design (CUTIPA-LUQUE approach yaw control) ********************
zeta=0.7;
wn=1;% 1; %observe that 1/T = 0.18 rad/s
kp=wn^2*T/k
kd=(2*zeta*wn^2*T-1)/k
% It results:
% kp=47.0388;
% kd=61.1438;
%**************************** SURGE CONTROL ************************************
%
% The model can be written as
% (m-xudot)u_dot=xu u + tau_u;
% the transfer function will be
%              1              1          k
% G(s)= ----------------- = ------ = -------
%        (m-xudot)s + xu     as+b     Ts + 1

% load linear model
load dataout/ltiX.mat

% Analysis of the model
A=linear.a;
B=linear.b;
C=linear.c;
D=linear.d;

% Y=[u, v, r, apsi]' and U=[tau_u, tau_r]'
ap=[A(1:3,1:3) A(1:3,6);  
    A(6,1:3)   A(6,6)];
bp=[B(1:3,:);
    B(6,:)];
cp=[C(1:3,1:3) C(1:3,6);
    C(6,1:3)   C(6,6)];
dp=[D(1:3,:);
    D(6,:)];

% Y=[u, apsi]' and U=[tau_u, tau_r]'
ap=ap(1,1);
bp=bp(1,1);
cp=cp(1,1);
dp=0;

sys = zpk(ss(ap,bp,cp,dp))     % Zeros, Poles, and Gains from u_i to x_j
[Z,P,K]=zpkdata(sys)
% surge veloc. and  froce tau_u transfer function
num2=K.*poly(Z{1,1});
den2=poly(P{1,1});
sys2=tf(num2,den2)
% standard normalized form for tf. Thus sys3=sys2
num3=num2./den2(2);
den3=den2./den2(2);
sys3=tf(num3,den3)
%
% The result gives a tf:
%          k         0.00527
% G(s)= ------- = -------------
%        Ts + 1    1.211 s + 1
%          k         0.008142
% G(s)= ------- = -------------
%        Ts + 1    1.531 s + 1
%
% Let K(s) be the PI controller for the surge motion expressed above
%
%               Ki
% K(s) =  Kp + ----
%                s
k=num3(1);
T=den3(1);

rate=188/140; %10; % relation ki/kp=rate
% Open loop tf
numL=k.*[1/rate 1];
denL=[T 1 0];
sysL=tf(numL,denL)
rlocus(sysL)

% closed loop transfer function
wn=1;
zeta=0.7;
ki=wn^2*T/k;
kp=2*zeta*ki/wn-1/k;

% It results:
% ki=229.71;%188;%68.5;
% kp=131.84;%140;%ki/rate;

numCL=[kp/ki 1];
denCL=[T/k/ki (1+k*kp)/k/ki 1];
sysCL=tf(numCL,denCL)
figure; pzmap(sysCL)
figure; step(sysCL)



        
