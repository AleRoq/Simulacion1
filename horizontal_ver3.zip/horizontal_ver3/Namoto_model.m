% control2.m is the siso control using modern control approaches found
% in classical books, written by OGATA, R. DORF, , between others.

% control of yaw angle control
% tranfer function
close all; clear all;
num=[0.0255 1.2915e-7]
den=[1 1.3167e-5 -0.2244]  % dot(yaw angle) 
%den=[1 1.3167e-5 -0.2244 0] % yaw angle

figure;
bode(num,den)
title('tf of the system G')

alphaT=1
numK=[1 alphaT]
denK=[1]

numL=conv(numK,num)
denL=conv(denK,den)

figure;
bode(numL,denL)
title('tf of the system L=KG')

%************** Testing a Namoto second order model ************************
% HROV sway-yaw linear model dynamics equations
% a1sv+a2sr+b1v+b2r=0                                                 (1)
% a3sv+a4sr+b3v+b4r=tau_r                                             (2) 
%
% from Eq. (1)
%
%         (a1s + b1)
% v= - ---------------  r                                              (3)
%      (a3s+b3)(a2s+b2)
%
% from Eqs. (3) and (2)
%
%
%   r                      (a1s + b1)
% ----- = ------------------------------------------------------      (4)
% tau_r    (a1a4-a2a3)s^2 + (b1a4+a1b4-b2a3-b3a2)s + (b1b4+b2b3)

% Example 1, consider coefficients represents a system
% 
a1=1
a2=2
a3=3
a4=4
b1=2
b2=3
b3=4
b4=5

num=[a1 b1]
den=[a1*a4-a2*a3 b1*a4+a1*b4-b2*a3-b3*a2 b1*b4-b2*b3]
num1=1/(a1*a4-a2*a3).*[a1 b1]
den1=1/(a1*a4-a2*a3).*[a1*a4-a2*a3 b1*a4+a1*b4-b2*a3-b3*a2 b1*b4-b2*b3]

% another approach is by state space. Let 
AA=[a1 a2;a3 a4];
BB=[b1 b2;b3 b4];
%
%         -1         -1
% Xdot=-AA  BB X + AA  [0 ; 1]U
%  y= C x
%
A=-inv(AA)*BB
B=inv(AA)*[0 ; 1]
C=[0 1];
D=0;
%             -1
% G(s)=C(sI-A)  B + D
%
sys = zpk(ss(A,B,C,D))     % Zeros, Poles, and Gains from u_i to x_j
[Z,P,K]=zpkdata(sys)
% surge tf
num2=K.*poly(Z{1,1});
den2=poly(P{1,1});

% Example 2, consider coefficients represents a actual HROV system
% from parameters.m
m=135.7;%m=150;
Iz=30.71;%Iz=19.5;% kg m^2;
xg=0.3e-3; % actual 57.60
xudot=-157;
yvdot=-197;
nrdot=-8.5;
yvv=-505.45/3;
nrr=-95.32/3;
%yvv=-505.45/6;
%nrr=-95.32/6;

u0=0.5;
a1=m-yvdot
a2=m*xg
a3=m*xg
a4=Iz-nrdot
b1=-yvv
b2=m*u0-xudot*u0
b3=-yvdot*u0+xudot*u0
b4=m*xg*u0-nrr

num3=1/(a1*a4-a2*a3).*[a1 b1]
den3=1/(a1*a4-a2*a3).*[a1*a4-a2*a3 b1*a4+a1*b4-b2*a3-b3*a2 b1*b4-b2*b3]
% Results
% the systems has an unstable pole with values
%	yvv=-505.45/6;
%	nrr=-95.32/6;
% num3 = 0.0255    0.0065
% den3 = 1.0000    0.6584   -0.1217
%
% and the system is stable with
%	yvv=-505.45/3;
%	nrr=-95.32/3;
% num3 = 0.0255    0.0129
% den3 = 1.0000    1.3167    0.1863
%
% Because the nonlinear model should be linearized using the
% 'linmod', the values of yvv and nvv may be inferiors and thus the linearized 
% system present still an unstable pole. The above are the results of the tf
% function obtained by linearizion (linmod)
%	yvv=-505.45/3;
%	nrr=-95.32/3;
% num=[0.0255 1.2915e-7]
% den=[1 1.3167e-5 -0.2244]
% CONCLUSSION: In order to avoid small linearized values for yvv and nrr, choose
% a positive operation point greater than 0, for example:
% xop=[0.5 0.25 0.01 0.0 0.0 0.0]';  % It is OK
% xop=[0.5 0.001 0.001 0.0 0.0 0.001]'; % it results in unstable system 'cos the
% variables v and r are close to zero and thus the valued derivatives of the
% expressions -Yvv|v|v and -Nrr|r|r give small linear values for -Yvv and -Nrr. 
% As consequence, the stability of the model may be seriously compromised.





