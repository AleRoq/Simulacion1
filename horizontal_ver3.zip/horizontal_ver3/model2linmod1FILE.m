% this file is applied to linearized models
clear all; close all;
xop=[0.5 0.0 0.0]';
uop=[50 0]';
linear=linmod('model2linmod1',xop,uop);
save ltiX.mat xop uop
