% parameters and coefficientes of the models
% Data
%load model2linmod1b.mat; % load linear model
global m Iz xg yg yp1 yp2 xudot yvdot nrdot yrdot nvdot xuu yvv nrr
global xu yv nr xu0 yv0 nr0
m=135.7;%m=150;
Iz=30.71;%Iz=19.5;% kg m^2;
xg=0.3e-3; % actual 57.60e-3;
yg=0;%-1.14e-3; the last value carry the vehicle forward to unstability
yp1=264e-3;
yp2=-264e-3;

factorX=1.67;%3;
xudot=-157/factorX;
yvdot=-197/factorX;
nrdot=-8.5/factorX;

xuu=-368.48/factorX;%-368.48/3;
yvv=-505.45/factorX;%-505.45/3;   % factorY
nrr=-95.32/factorX;%-95.32/3;

% quadratic coeff. for Dv
xuu=-767.4455;  % experimental test
yvv=-1000.2323; % estimated 
nrr=-83.9085;   % experimental test
% linear coeff. for Dv
xu=-19.7802;  % experimental test
yv=0; % estimated 
nr=-2.2687;   % experimental test
% constans for Dv
xu0=-0.0457; % experimental test
yv0=0; % estimated
nr0=-0.3989; % experimental test
%xuu=-200;
%yvv=-200;
%nrr=-50;
%simulation parameters
x0=[0.001;0.0;0.0;0.0;0.0;0.0001];
