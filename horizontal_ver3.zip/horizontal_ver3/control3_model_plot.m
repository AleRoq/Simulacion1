close all; clear all;
load dataout/control3_sim.mat 
%
%********************* Figures to be analysed **********************************
t=resp(1,:);
fsz=14;
figure;
% surge veloc. [ref, siso resp, linear resp, nonlinear resp ] 
plot(t,[resp(2,:);resp(4,:);resp(8,:);resp(18,:)]) 
ylabel('Amplitude (m/s)'); xlabel('Time (s)')
figure;
% yaw angle    [ref, siso resp, linear resp, nonlinear resp ] 
plot(t,180/3.14.*[resp(3,:);resp(5,:);resp(13,:);resp(23,:)])
ylabel('Amplitude (rad)'); xlabel('Time (s)')

figure;
%
plot(t,180/3.14.*[resp(3,:);resp(5,:);resp(13,:);resp(23,:)])
ylabel('Amplitude (rad)','fontsize',fsz); xlabel('Time (s)','fontsize',fsz)
set(gca,'fontsize',fsz); % set size of fonts bigger than default set

%********************* Figures to be saved *************************************
set(0,'DefaultAxesColorOrder',[0 0 0],...
      'DefaultAxesLineStyleOrder','-|-.|--|:')
set(gca,'fontsize',fsz); % set size of fonts bigger than default set
plot(t,resp(18,:),'LineWidth',2);
hold all
plot(t,resp(8,:),'LineWidth',2);
hold all
plot(t,resp(2,:),'LineWidth',2);
ylabel('Amplitude (m/s)','fontsize',fsz); xlabel('Time (s)','fontsize',fsz)
legend('nonlinear response','linear response','reference')
display('ensure the below figure legend does not accross plot lines, and press RETURN to continue')
pause
saveas(gcf,'dataout/figures/control3/fig1.eps', 'psc2')
saveas(gcf,'dataout/figures/control3/fig1.fig')
saveas(gcf,'dataout/figures/control3/fig1.png')

hold off
% figure 2
plot(t,180/3.1416.*resp(20,:),'LineWidth',2);
hold all
plot(t,180/3.1416.*resp(10,:),'LineWidth',2);
hold all
plot(t,180/3.1416.*resp(3,:),'LineWidth',2);
ylabel('Amplitude (degrees/s)','fontsize',fsz); xlabel('Time (s)','fontsize',fsz)
legend('nonlinear response','linear response','reference')
display('ensure the below figure legend does not across plot lines, and press RETURN to continue')
pause
saveas(gcf,'dataout/figures/control3/fig2.eps', 'psc2')
saveas(gcf,'dataout/figures/control3/fig2.fig')
saveas(gcf,'dataout/figures/control3/fig2.png')

hold off
% figure 3
plot(t,resp(24,:),'LineWidth',2)
hold all
plot(t,resp(25,:),'LineWidth',2)
ylabel('Amplitude (N, N-m)','fontsize',fsz); xlabel('Time (s)','fontsize',fsz)
legend('Force {\tau}_u','Moment {\tau}_r')
display('ensure the below figure legend does not across plot lines, and press RETURN to continue')
pause
saveas(gcf,'dataout/figures/control3/fig3.eps', 'psc2')
saveas(gcf,'dataout/figures/control3/fig3.fig')
saveas(gcf,'dataout/figures/control3/fig3.png')

hold off
% figure 4
plot(t,resp(26,:),'LineWidth',2)
hold all
plot(t,resp(27,:),'LineWidth',2)
ylabel('Amplitude (N, N)','fontsize',fsz); xlabel('Time (s)','fontsize',fsz)
legend('Force {\tau}_1','Force {\tau}_2')
display('ensure the below figure legend does not across plot lines, and press RETURN to continue')
pause
saveas(gcf,'dataout/figures/control3/fig4.eps', 'psc2')
saveas(gcf,'dataout/figures/control3/fig4.fig')
saveas(gcf,'dataout/figures/control3/fig4.png')





