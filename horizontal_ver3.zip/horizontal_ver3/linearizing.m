% this file is applied to linearize models
clear all; close all;
xop=[0.43 0.25 0.1 0.0 0.0 0.1]';
%xop=[0.5 0.15 0.1 0.0 0.0 0.1]';
%xop=[0.5 0.25 0.01 0.0 0.0 0.0]';
%xop=[0.5 0.001 0.001 0.0 0.0 0.001]'; % warning 4th order system
%uop=[10 50]';
uop=[2.5 2.5]';
linear=linmod('model2linmod1',xop,uop)
%save dataout/ltiX.mat linear xop uop 

