#include "__cf_teste1.h"
#ifndef RTW_HEADER_teste1_acc_h_
#define RTW_HEADER_teste1_acc_h_
#ifndef teste1_acc_COMMON_INCLUDES_
#define teste1_acc_COMMON_INCLUDES_
#include <stdlib.h>
#include <stddef.h>
#define S_FUNCTION_NAME simulink_only_sfcn 
#define S_FUNCTION_LEVEL 2
#define RTW_GENERATED_S_FUNCTION
#include "rtwtypes.h"
#include "simstruc.h"
#include "fixedpoint.h"
#include "rt_defines.h"
#endif
#include "teste1_acc_types.h"
typedef struct { real_T B_0_0_0 [ 2 ] ; real_T B_0_2_0 [ 2 ] ; real_T B_0_6_0
; real_T B_0_7_0 ; real_T B_0_8_0 ; real_T B_0_9_0 ; real_T B_0_10_0 [ 2 ] ;
real_T B_0_12_0 [ 2 ] ; real_T B_0_13_0 [ 2 ] ; real_T B_0_17_0 ; real_T
B_0_18_0 ; real_T B_0_19_0 ; real_T B_0_20_0 ; real_T B_0_21_0 [ 2 ] ; real_T
B_0_22_0 [ 2 ] ; real_T B_0_23_0 [ 6 ] ; real_T B_0_26_0 [ 2 ] ; real_T
B_0_27_0 [ 2 ] ; real_T B_0_29_0 [ 2 ] ; real_T B_0_31_0 [ 6 ] ; real_T
B_0_32_0 ; real_T B_0_33_0 ; real_T B_0_34_0 ; real_T B_0_35_0 ; real_T
B_0_36_0 [ 2 ] ; real_T B_0_37_0 [ 2 ] ; } BlockIO_teste1 ; typedef struct {
struct { void * LoggedData ; } Scope10_PWORK ; struct { void * LoggedData ; }
Scope11_PWORK ; struct { void * LoggedData ; } Scope9_PWORK ; struct { void *
LoggedData ; } Scope1_PWORK ; struct { void * LoggedData ; } Scope2_PWORK ;
struct { void * LoggedData ; } Scope3_PWORK ; struct { void * LoggedData ; }
Scope4_PWORK ; struct { void * LoggedData ; } Scope5_PWORK ; struct { void *
LoggedData ; } Scope7_PWORK ; char pad_Scope7_PWORK [ 4 ] ; } D_Work_teste1 ;
typedef struct { real_T StateSpace1_CSTATE [ 4 ] ; real_T
HinfinityController_CSTATE [ 14 ] ; real_T StateSpace2_CSTATE [ 4 ] ; real_T
HinfinityController1_CSTATE [ 14 ] ; real_T Integrator_CSTATE [ 6 ] ; real_T
HinfinityController2_CSTATE [ 14 ] ; } ContinuousStates_teste1 ; typedef
struct { real_T StateSpace1_CSTATE [ 4 ] ; real_T HinfinityController_CSTATE
[ 14 ] ; real_T StateSpace2_CSTATE [ 4 ] ; real_T HinfinityController1_CSTATE
[ 14 ] ; real_T Integrator_CSTATE [ 6 ] ; real_T HinfinityController2_CSTATE
[ 14 ] ; } StateDerivatives_teste1 ; typedef struct { boolean_T
StateSpace1_CSTATE [ 4 ] ; boolean_T HinfinityController_CSTATE [ 14 ] ;
boolean_T StateSpace2_CSTATE [ 4 ] ; boolean_T HinfinityController1_CSTATE [
14 ] ; boolean_T Integrator_CSTATE [ 6 ] ; boolean_T
HinfinityController2_CSTATE [ 14 ] ; } StateDisabled_teste1 ; typedef struct
{ real_T * B_0_1 [ 2 ] ; real_T * B_0_7 [ 2 ] ; real_T * B_0_13 [ 6 ] ; }
ExternalOutputs_teste1 ; struct Parameters_teste1_ { real_T P_0 [ 10 ] ;
real_T P_1 [ 3 ] ; real_T P_2 [ 2 ] ; real_T P_4 ; real_T P_5 [ 196 ] ;
real_T P_6 [ 28 ] ; real_T P_7 [ 28 ] ; real_T P_9 ; real_T P_10 ; real_T
P_11 ; real_T P_12 [ 10 ] ; real_T P_13 [ 3 ] ; real_T P_14 [ 2 ] ; real_T
P_16 ; real_T P_17 [ 196 ] ; real_T P_18 [ 28 ] ; real_T P_19 [ 28 ] ; real_T
P_21 ; real_T P_22 [ 4 ] ; real_T P_23 ; real_T P_24 ; real_T P_25 [ 4 ] ;
real_T P_26 [ 6 ] ; real_T P_27 [ 196 ] ; real_T P_28 [ 28 ] ; real_T P_29 [
28 ] ; real_T P_31 ; real_T P_32 [ 4 ] ; real_T P_33 [ 4 ] ; real_T P_34 ;
real_T P_35 ; real_T P_36 [ 4 ] ; } ; extern Parameters_teste1
teste1_rtDefaultParameters ;
#endif
