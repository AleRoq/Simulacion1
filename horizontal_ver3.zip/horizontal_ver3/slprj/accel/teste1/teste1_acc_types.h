#include "__cf_teste1.h"
#ifndef RTW_HEADER_teste1_acc_types_h_
#define RTW_HEADER_teste1_acc_types_h_
#include "rtwtypes.h"
typedef struct Parameters_teste1_ Parameters_teste1 ;
#endif
