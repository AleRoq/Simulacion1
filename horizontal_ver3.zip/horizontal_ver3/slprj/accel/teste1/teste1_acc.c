#include "__cf_teste1.h"
#include <math.h>
#include "teste1_acc.h"
#include "teste1_acc_private.h"
#include <stdio.h>
#include "simstruc.h"
#include "fixedpoint.h"
#define CodeFormat S-Function
#define AccDefine1 Accelerator_S-Function
static void mdlOutputs ( SimStruct * S , int_T tid ) { BlockIO_teste1 * _rtB
; Parameters_teste1 * _rtP ; D_Work_teste1 * _rtDW ; _rtDW = ( (
D_Work_teste1 * ) ssGetRootDWork ( S ) ) ; _rtP = ( ( Parameters_teste1 * )
ssGetDefaultParam ( S ) ) ; _rtB = ( ( BlockIO_teste1 * ) _ssGetBlockIO ( S )
) ; { ( ( BlockIO_teste1 * ) _ssGetBlockIO ( S ) ) -> B_0_0_0 [ 0 ] = ( ( (
Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_2 [ 0 ] ) * ( (
ContinuousStates_teste1 * ) ssGetContStates ( S ) ) -> StateSpace1_CSTATE [ 0
] ; ( ( BlockIO_teste1 * ) _ssGetBlockIO ( S ) ) -> B_0_0_0 [ 1 ] = ( ( (
Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_2 [ 1 ] ) * ( (
ContinuousStates_teste1 * ) ssGetContStates ( S ) ) -> StateSpace1_CSTATE [ 3
] ; } ssCallAccelRunBlock ( S , 0 , 1 , SS_CALL_MDL_OUTPUTS ) ; { { static
const int_T colCidxRow0 [ 14 ] = { 0 , 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 , 10
, 11 , 12 , 13 } ; const int_T * pCidx = & colCidxRow0 [ 0 ] ; const real_T *
pC0 = ( ( Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_7 ; const
real_T * xc = & ( ( ContinuousStates_teste1 * ) ssGetContStates ( S ) ) ->
HinfinityController_CSTATE [ 0 ] ; real_T * y0 = & ( ( BlockIO_teste1 * )
_ssGetBlockIO ( S ) ) -> B_0_2_0 [ 0 ] ; int_T numNonZero = 13 ; * y0 = ( *
pC0 ++ ) * xc [ * pCidx ++ ] ; while ( numNonZero -- ) { * y0 += ( * pC0 ++ )
* xc [ * pCidx ++ ] ; } } { static const int_T colCidxRow1 [ 14 ] = { 0 , 1 ,
2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 , 10 , 11 , 12 , 13 } ; const int_T * pCidx = &
colCidxRow1 [ 0 ] ; const real_T * pC14 = & ( ( Parameters_teste1 * )
ssGetDefaultParam ( S ) ) -> P_7 [ 14 ] ; const real_T * xc = & ( (
ContinuousStates_teste1 * ) ssGetContStates ( S ) ) ->
HinfinityController_CSTATE [ 0 ] ; real_T * y1 = & ( ( BlockIO_teste1 * )
_ssGetBlockIO ( S ) ) -> B_0_2_0 [ 1 ] ; int_T numNonZero = 13 ; * y1 = ( *
pC14 ++ ) * xc [ * pCidx ++ ] ; while ( numNonZero -- ) { * y1 += ( * pC14 ++
) * xc [ * pCidx ++ ] ; } } } ssCallAccelRunBlock ( S , 0 , 3 ,
SS_CALL_MDL_OUTPUTS ) ; ssCallAccelRunBlock ( S , 0 , 4 , SS_CALL_MDL_OUTPUTS
) ; ssCallAccelRunBlock ( S , 0 , 5 , SS_CALL_MDL_OUTPUTS ) ; if (
ssIsSampleHit ( S , 1 , 0 ) ) { _rtB -> B_0_6_0 = _rtP -> P_10 ; } _rtB ->
B_0_7_0 = _rtB -> B_0_6_0 - _rtB -> B_0_0_0 [ 0 ] ; if ( ssIsSampleHit ( S ,
1 , 0 ) ) { _rtB -> B_0_8_0 = _rtP -> P_11 ; } _rtB -> B_0_9_0 = _rtB ->
B_0_8_0 - _rtB -> B_0_0_0 [ 1 ] ; { ( ( BlockIO_teste1 * ) _ssGetBlockIO ( S
) ) -> B_0_10_0 [ 0 ] = ( ( ( Parameters_teste1 * ) ssGetDefaultParam ( S ) )
-> P_14 [ 0 ] ) * ( ( ContinuousStates_teste1 * ) ssGetContStates ( S ) ) ->
StateSpace2_CSTATE [ 0 ] ; ( ( BlockIO_teste1 * ) _ssGetBlockIO ( S ) ) ->
B_0_10_0 [ 1 ] = ( ( ( Parameters_teste1 * ) ssGetDefaultParam ( S ) ) ->
P_14 [ 1 ] ) * ( ( ContinuousStates_teste1 * ) ssGetContStates ( S ) ) ->
StateSpace2_CSTATE [ 3 ] ; } ssCallAccelRunBlock ( S , 0 , 11 ,
SS_CALL_MDL_OUTPUTS ) ; { { static const int_T colCidxRow0 [ 14 ] = { 0 , 1 ,
2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 , 10 , 11 , 12 , 13 } ; const int_T * pCidx = &
colCidxRow0 [ 0 ] ; const real_T * pC0 = ( ( Parameters_teste1 * )
ssGetDefaultParam ( S ) ) -> P_19 ; const real_T * xc = & ( (
ContinuousStates_teste1 * ) ssGetContStates ( S ) ) ->
HinfinityController1_CSTATE [ 0 ] ; real_T * y0 = & ( ( BlockIO_teste1 * )
_ssGetBlockIO ( S ) ) -> B_0_12_0 [ 0 ] ; int_T numNonZero = 13 ; * y0 = ( *
pC0 ++ ) * xc [ * pCidx ++ ] ; while ( numNonZero -- ) { * y0 += ( * pC0 ++ )
* xc [ * pCidx ++ ] ; } } { static const int_T colCidxRow1 [ 14 ] = { 0 , 1 ,
2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 , 10 , 11 , 12 , 13 } ; const int_T * pCidx = &
colCidxRow1 [ 0 ] ; const real_T * pC14 = & ( ( Parameters_teste1 * )
ssGetDefaultParam ( S ) ) -> P_19 [ 14 ] ; const real_T * xc = & ( (
ContinuousStates_teste1 * ) ssGetContStates ( S ) ) ->
HinfinityController1_CSTATE [ 0 ] ; real_T * y1 = & ( ( BlockIO_teste1 * )
_ssGetBlockIO ( S ) ) -> B_0_12_0 [ 1 ] ; int_T numNonZero = 13 ; * y1 = ( *
pC14 ++ ) * xc [ * pCidx ++ ] ; while ( numNonZero -- ) { * y1 += ( * pC14 ++
) * xc [ * pCidx ++ ] ; } } } _rtB -> B_0_13_0 [ 0 ] = 0.0 ; _rtB -> B_0_13_0
[ 0 ] += _rtP -> P_22 [ 0 ] * _rtB -> B_0_12_0 [ 0 ] ; _rtB -> B_0_13_0 [ 0 ]
+= _rtP -> P_22 [ 2 ] * _rtB -> B_0_12_0 [ 1 ] ; _rtB -> B_0_13_0 [ 1 ] = 0.0
; _rtB -> B_0_13_0 [ 1 ] += _rtP -> P_22 [ 1 ] * _rtB -> B_0_12_0 [ 0 ] ;
_rtB -> B_0_13_0 [ 1 ] += _rtP -> P_22 [ 3 ] * _rtB -> B_0_12_0 [ 1 ] ;
ssCallAccelRunBlock ( S , 0 , 14 , SS_CALL_MDL_OUTPUTS ) ;
ssCallAccelRunBlock ( S , 0 , 15 , SS_CALL_MDL_OUTPUTS ) ;
ssCallAccelRunBlock ( S , 0 , 16 , SS_CALL_MDL_OUTPUTS ) ; if ( ssIsSampleHit
( S , 1 , 0 ) ) { _rtB -> B_0_17_0 = _rtP -> P_23 ; } _rtB -> B_0_18_0 = _rtB
-> B_0_17_0 - _rtB -> B_0_10_0 [ 0 ] ; if ( ssIsSampleHit ( S , 1 , 0 ) ) {
_rtB -> B_0_19_0 = _rtP -> P_24 ; } _rtB -> B_0_20_0 = _rtB -> B_0_19_0 -
_rtB -> B_0_10_0 [ 1 ] ; _rtB -> B_0_21_0 [ 0 ] = _rtB -> B_0_18_0 ; _rtB ->
B_0_21_0 [ 1 ] = _rtB -> B_0_20_0 ; _rtB -> B_0_22_0 [ 0 ] = 0.0 ; _rtB ->
B_0_22_0 [ 0 ] += _rtP -> P_25 [ 0 ] * _rtB -> B_0_21_0 [ 0 ] ; _rtB ->
B_0_22_0 [ 0 ] += _rtP -> P_25 [ 2 ] * _rtB -> B_0_21_0 [ 1 ] ; _rtB ->
B_0_22_0 [ 1 ] = 0.0 ; _rtB -> B_0_22_0 [ 1 ] += _rtP -> P_25 [ 1 ] * _rtB ->
B_0_21_0 [ 0 ] ; _rtB -> B_0_22_0 [ 1 ] += _rtP -> P_25 [ 3 ] * _rtB ->
B_0_21_0 [ 1 ] ; { int_T i1 ; real_T * y0 = ( ( BlockIO_teste1 * )
_ssGetBlockIO ( S ) ) -> B_0_23_0 ; real_T * xc = & ( (
ContinuousStates_teste1 * ) ssGetContStates ( S ) ) -> Integrator_CSTATE [ 0
] ; for ( i1 = 0 ; i1 < 6 ; i1 ++ ) { y0 [ i1 ] = xc [ i1 ] ; } }
ssCallAccelRunBlock ( S , 0 , 24 , SS_CALL_MDL_OUTPUTS ) ;
ssCallAccelRunBlock ( S , 0 , 25 , SS_CALL_MDL_OUTPUTS ) ; { { static const
int_T colCidxRow0 [ 14 ] = { 0 , 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 , 10 , 11
, 12 , 13 } ; const int_T * pCidx = & colCidxRow0 [ 0 ] ; const real_T * pC0
= ( ( Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_29 ; const real_T
* xc = & ( ( ContinuousStates_teste1 * ) ssGetContStates ( S ) ) ->
HinfinityController2_CSTATE [ 0 ] ; real_T * y0 = & ( ( BlockIO_teste1 * )
_ssGetBlockIO ( S ) ) -> B_0_26_0 [ 0 ] ; int_T numNonZero = 13 ; * y0 = ( *
pC0 ++ ) * xc [ * pCidx ++ ] ; while ( numNonZero -- ) { * y0 += ( * pC0 ++ )
* xc [ * pCidx ++ ] ; } } { static const int_T colCidxRow1 [ 14 ] = { 0 , 1 ,
2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 , 10 , 11 , 12 , 13 } ; const int_T * pCidx = &
colCidxRow1 [ 0 ] ; const real_T * pC14 = & ( ( Parameters_teste1 * )
ssGetDefaultParam ( S ) ) -> P_29 [ 14 ] ; const real_T * xc = & ( (
ContinuousStates_teste1 * ) ssGetContStates ( S ) ) ->
HinfinityController2_CSTATE [ 0 ] ; real_T * y1 = & ( ( BlockIO_teste1 * )
_ssGetBlockIO ( S ) ) -> B_0_26_0 [ 1 ] ; int_T numNonZero = 13 ; * y1 = ( *
pC14 ++ ) * xc [ * pCidx ++ ] ; while ( numNonZero -- ) { * y1 += ( * pC14 ++
) * xc [ * pCidx ++ ] ; } } } _rtB -> B_0_27_0 [ 0 ] = 0.0 ; _rtB -> B_0_27_0
[ 0 ] += _rtP -> P_32 [ 0 ] * _rtB -> B_0_26_0 [ 0 ] ; _rtB -> B_0_27_0 [ 0 ]
+= _rtP -> P_32 [ 2 ] * _rtB -> B_0_26_0 [ 1 ] ; _rtB -> B_0_27_0 [ 1 ] = 0.0
; _rtB -> B_0_27_0 [ 1 ] += _rtP -> P_32 [ 1 ] * _rtB -> B_0_26_0 [ 0 ] ;
_rtB -> B_0_27_0 [ 1 ] += _rtP -> P_32 [ 3 ] * _rtB -> B_0_26_0 [ 1 ] ;
ssCallAccelRunBlock ( S , 0 , 28 , SS_CALL_MDL_OUTPUTS ) ; _rtB -> B_0_29_0 [
0 ] = 0.0 ; _rtB -> B_0_29_0 [ 0 ] += _rtP -> P_33 [ 0 ] * _rtB -> B_0_27_0 [
0 ] ; _rtB -> B_0_29_0 [ 0 ] += _rtP -> P_33 [ 2 ] * _rtB -> B_0_27_0 [ 1 ] ;
_rtB -> B_0_29_0 [ 1 ] = 0.0 ; _rtB -> B_0_29_0 [ 1 ] += _rtP -> P_33 [ 1 ] *
_rtB -> B_0_27_0 [ 0 ] ; _rtB -> B_0_29_0 [ 1 ] += _rtP -> P_33 [ 3 ] * _rtB
-> B_0_27_0 [ 1 ] ; ssCallAccelRunBlock ( S , 0 , 30 , SS_CALL_MDL_OUTPUTS )
; ssCallAccelRunBlock ( S , 0 , 31 , SS_CALL_MDL_OUTPUTS ) ; if (
ssIsSampleHit ( S , 1 , 0 ) ) { _rtB -> B_0_32_0 = _rtP -> P_34 ; } _rtB ->
B_0_33_0 = _rtB -> B_0_32_0 - _rtB -> B_0_23_0 [ 0 ] ; if ( ssIsSampleHit ( S
, 1 , 0 ) ) { _rtB -> B_0_34_0 = _rtP -> P_35 ; } _rtB -> B_0_35_0 = _rtB ->
B_0_34_0 - _rtB -> B_0_23_0 [ 5 ] ; _rtB -> B_0_36_0 [ 0 ] = _rtB -> B_0_33_0
; _rtB -> B_0_36_0 [ 1 ] = _rtB -> B_0_35_0 ; _rtB -> B_0_37_0 [ 0 ] = 0.0 ;
_rtB -> B_0_37_0 [ 0 ] += _rtP -> P_36 [ 0 ] * _rtB -> B_0_36_0 [ 0 ] ; _rtB
-> B_0_37_0 [ 0 ] += _rtP -> P_36 [ 2 ] * _rtB -> B_0_36_0 [ 1 ] ; _rtB ->
B_0_37_0 [ 1 ] = 0.0 ; _rtB -> B_0_37_0 [ 1 ] += _rtP -> P_36 [ 1 ] * _rtB ->
B_0_36_0 [ 0 ] ; _rtB -> B_0_37_0 [ 1 ] += _rtP -> P_36 [ 3 ] * _rtB ->
B_0_36_0 [ 1 ] ; UNUSED_PARAMETER ( tid ) ; }
#define MDL_UPDATE
static void mdlUpdate ( SimStruct * S , int_T tid ) { BlockIO_teste1 * _rtB ;
_rtB = ( ( BlockIO_teste1 * ) _ssGetBlockIO ( S ) ) ; UNUSED_PARAMETER ( tid
) ; }
#define MDL_DERIVATIVES
static void mdlDerivatives ( SimStruct * S ) { BlockIO_teste1 * _rtB ; _rtB =
( ( BlockIO_teste1 * ) _ssGetBlockIO ( S ) ) ; { ( ( StateDerivatives_teste1
* ) ssGetdX ( S ) ) -> StateSpace1_CSTATE [ 0 ] = ( ( ( Parameters_teste1 * )
ssGetDefaultParam ( S ) ) -> P_0 [ 0 ] ) * ( ( ContinuousStates_teste1 * )
ssGetContStates ( S ) ) -> StateSpace1_CSTATE [ 0 ] + ( ( ( Parameters_teste1
* ) ssGetDefaultParam ( S ) ) -> P_0 [ 1 ] ) * ( ( ContinuousStates_teste1 *
) ssGetContStates ( S ) ) -> StateSpace1_CSTATE [ 1 ] + ( ( (
Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_0 [ 2 ] ) * ( (
ContinuousStates_teste1 * ) ssGetContStates ( S ) ) -> StateSpace1_CSTATE [ 2
] ; ( ( StateDerivatives_teste1 * ) ssGetdX ( S ) ) -> StateSpace1_CSTATE [ 0
] += ( ( ( Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_1 [ 0 ] ) * (
( BlockIO_teste1 * ) _ssGetBlockIO ( S ) ) -> B_0_2_0 [ 0 ] ; ( (
StateDerivatives_teste1 * ) ssGetdX ( S ) ) -> StateSpace1_CSTATE [ 1 ] = ( (
( Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_0 [ 3 ] ) * ( (
ContinuousStates_teste1 * ) ssGetContStates ( S ) ) -> StateSpace1_CSTATE [ 0
] + ( ( ( Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_0 [ 4 ] ) * (
( ContinuousStates_teste1 * ) ssGetContStates ( S ) ) -> StateSpace1_CSTATE [
1 ] + ( ( ( Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_0 [ 5 ] ) *
( ( ContinuousStates_teste1 * ) ssGetContStates ( S ) ) -> StateSpace1_CSTATE
[ 2 ] ; ( ( StateDerivatives_teste1 * ) ssGetdX ( S ) ) -> StateSpace1_CSTATE
[ 1 ] += ( ( ( Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_1 [ 1 ] )
* ( ( BlockIO_teste1 * ) _ssGetBlockIO ( S ) ) -> B_0_2_0 [ 1 ] ; ( (
StateDerivatives_teste1 * ) ssGetdX ( S ) ) -> StateSpace1_CSTATE [ 2 ] = ( (
( Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_0 [ 6 ] ) * ( (
ContinuousStates_teste1 * ) ssGetContStates ( S ) ) -> StateSpace1_CSTATE [ 0
] + ( ( ( Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_0 [ 7 ] ) * (
( ContinuousStates_teste1 * ) ssGetContStates ( S ) ) -> StateSpace1_CSTATE [
1 ] + ( ( ( Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_0 [ 8 ] ) *
( ( ContinuousStates_teste1 * ) ssGetContStates ( S ) ) -> StateSpace1_CSTATE
[ 2 ] ; ( ( StateDerivatives_teste1 * ) ssGetdX ( S ) ) -> StateSpace1_CSTATE
[ 2 ] += ( ( ( Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_1 [ 2 ] )
* ( ( BlockIO_teste1 * ) _ssGetBlockIO ( S ) ) -> B_0_2_0 [ 1 ] ; ( (
StateDerivatives_teste1 * ) ssGetdX ( S ) ) -> StateSpace1_CSTATE [ 3 ] = ( (
( Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_0 [ 9 ] ) * ( (
ContinuousStates_teste1 * ) ssGetContStates ( S ) ) -> StateSpace1_CSTATE [ 2
] ; } { { static const int_T colAidxRow0 [ 14 ] = { 0 , 1 , 2 , 3 , 4 , 5 , 6
, 7 , 8 , 9 , 10 , 11 , 12 , 13 } ; const int_T * pAidx = & colAidxRow0 [ 0 ]
; const real_T * pA0 = ( ( Parameters_teste1 * ) ssGetDefaultParam ( S ) ) ->
P_5 ; const real_T * xc = & ( ( ContinuousStates_teste1 * ) ssGetContStates (
S ) ) -> HinfinityController_CSTATE [ 0 ] ; real_T * dx0 = & ( (
StateDerivatives_teste1 * ) ssGetdX ( S ) ) -> HinfinityController_CSTATE [ 0
] ; int_T numNonZero = 13 ; * dx0 = ( * pA0 ++ ) * xc [ * pAidx ++ ] ; while
( numNonZero -- ) { * dx0 += ( * pA0 ++ ) * xc [ * pAidx ++ ] ; } } ( (
StateDerivatives_teste1 * ) ssGetdX ( S ) ) -> HinfinityController_CSTATE [ 0
] += ( ( ( Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_6 [ 0 ] ) * (
( BlockIO_teste1 * ) _ssGetBlockIO ( S ) ) -> B_0_7_0 + ( ( (
Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_6 [ 1 ] ) * ( (
BlockIO_teste1 * ) _ssGetBlockIO ( S ) ) -> B_0_9_0 ; { static const int_T
colAidxRow1 [ 14 ] = { 0 , 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 , 10 , 11 , 12 ,
13 } ; const int_T * pAidx = & colAidxRow1 [ 0 ] ; const real_T * pA14 = & (
( Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_5 [ 14 ] ; const
real_T * xc = & ( ( ContinuousStates_teste1 * ) ssGetContStates ( S ) ) ->
HinfinityController_CSTATE [ 0 ] ; real_T * dx1 = & ( (
StateDerivatives_teste1 * ) ssGetdX ( S ) ) -> HinfinityController_CSTATE [ 1
] ; int_T numNonZero = 13 ; * dx1 = ( * pA14 ++ ) * xc [ * pAidx ++ ] ; while
( numNonZero -- ) { * dx1 += ( * pA14 ++ ) * xc [ * pAidx ++ ] ; } } ( (
StateDerivatives_teste1 * ) ssGetdX ( S ) ) -> HinfinityController_CSTATE [ 1
] += ( ( ( Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_6 [ 2 ] ) * (
( BlockIO_teste1 * ) _ssGetBlockIO ( S ) ) -> B_0_7_0 + ( ( (
Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_6 [ 3 ] ) * ( (
BlockIO_teste1 * ) _ssGetBlockIO ( S ) ) -> B_0_9_0 ; { static const int_T
colAidxRow2 [ 14 ] = { 0 , 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 , 10 , 11 , 12 ,
13 } ; const int_T * pAidx = & colAidxRow2 [ 0 ] ; const real_T * pA28 = & (
( Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_5 [ 28 ] ; const
real_T * xc = & ( ( ContinuousStates_teste1 * ) ssGetContStates ( S ) ) ->
HinfinityController_CSTATE [ 0 ] ; real_T * dx2 = & ( (
StateDerivatives_teste1 * ) ssGetdX ( S ) ) -> HinfinityController_CSTATE [ 2
] ; int_T numNonZero = 13 ; * dx2 = ( * pA28 ++ ) * xc [ * pAidx ++ ] ; while
( numNonZero -- ) { * dx2 += ( * pA28 ++ ) * xc [ * pAidx ++ ] ; } } ( (
StateDerivatives_teste1 * ) ssGetdX ( S ) ) -> HinfinityController_CSTATE [ 2
] += ( ( ( Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_6 [ 4 ] ) * (
( BlockIO_teste1 * ) _ssGetBlockIO ( S ) ) -> B_0_7_0 + ( ( (
Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_6 [ 5 ] ) * ( (
BlockIO_teste1 * ) _ssGetBlockIO ( S ) ) -> B_0_9_0 ; { static const int_T
colAidxRow3 [ 14 ] = { 0 , 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 , 10 , 11 , 12 ,
13 } ; const int_T * pAidx = & colAidxRow3 [ 0 ] ; const real_T * pA42 = & (
( Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_5 [ 42 ] ; const
real_T * xc = & ( ( ContinuousStates_teste1 * ) ssGetContStates ( S ) ) ->
HinfinityController_CSTATE [ 0 ] ; real_T * dx3 = & ( (
StateDerivatives_teste1 * ) ssGetdX ( S ) ) -> HinfinityController_CSTATE [ 3
] ; int_T numNonZero = 13 ; * dx3 = ( * pA42 ++ ) * xc [ * pAidx ++ ] ; while
( numNonZero -- ) { * dx3 += ( * pA42 ++ ) * xc [ * pAidx ++ ] ; } } ( (
StateDerivatives_teste1 * ) ssGetdX ( S ) ) -> HinfinityController_CSTATE [ 3
] += ( ( ( Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_6 [ 6 ] ) * (
( BlockIO_teste1 * ) _ssGetBlockIO ( S ) ) -> B_0_7_0 + ( ( (
Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_6 [ 7 ] ) * ( (
BlockIO_teste1 * ) _ssGetBlockIO ( S ) ) -> B_0_9_0 ; { static const int_T
colAidxRow4 [ 14 ] = { 0 , 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 , 10 , 11 , 12 ,
13 } ; const int_T * pAidx = & colAidxRow4 [ 0 ] ; const real_T * pA56 = & (
( Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_5 [ 56 ] ; const
real_T * xc = & ( ( ContinuousStates_teste1 * ) ssGetContStates ( S ) ) ->
HinfinityController_CSTATE [ 0 ] ; real_T * dx4 = & ( (
StateDerivatives_teste1 * ) ssGetdX ( S ) ) -> HinfinityController_CSTATE [ 4
] ; int_T numNonZero = 13 ; * dx4 = ( * pA56 ++ ) * xc [ * pAidx ++ ] ; while
( numNonZero -- ) { * dx4 += ( * pA56 ++ ) * xc [ * pAidx ++ ] ; } } ( (
StateDerivatives_teste1 * ) ssGetdX ( S ) ) -> HinfinityController_CSTATE [ 4
] += ( ( ( Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_6 [ 8 ] ) * (
( BlockIO_teste1 * ) _ssGetBlockIO ( S ) ) -> B_0_7_0 + ( ( (
Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_6 [ 9 ] ) * ( (
BlockIO_teste1 * ) _ssGetBlockIO ( S ) ) -> B_0_9_0 ; { static const int_T
colAidxRow5 [ 14 ] = { 0 , 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 , 10 , 11 , 12 ,
13 } ; const int_T * pAidx = & colAidxRow5 [ 0 ] ; const real_T * pA70 = & (
( Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_5 [ 70 ] ; const
real_T * xc = & ( ( ContinuousStates_teste1 * ) ssGetContStates ( S ) ) ->
HinfinityController_CSTATE [ 0 ] ; real_T * dx5 = & ( (
StateDerivatives_teste1 * ) ssGetdX ( S ) ) -> HinfinityController_CSTATE [ 5
] ; int_T numNonZero = 13 ; * dx5 = ( * pA70 ++ ) * xc [ * pAidx ++ ] ; while
( numNonZero -- ) { * dx5 += ( * pA70 ++ ) * xc [ * pAidx ++ ] ; } } ( (
StateDerivatives_teste1 * ) ssGetdX ( S ) ) -> HinfinityController_CSTATE [ 5
] += ( ( ( Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_6 [ 10 ] ) *
( ( BlockIO_teste1 * ) _ssGetBlockIO ( S ) ) -> B_0_7_0 + ( ( (
Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_6 [ 11 ] ) * ( (
BlockIO_teste1 * ) _ssGetBlockIO ( S ) ) -> B_0_9_0 ; { static const int_T
colAidxRow6 [ 14 ] = { 0 , 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 , 10 , 11 , 12 ,
13 } ; const int_T * pAidx = & colAidxRow6 [ 0 ] ; const real_T * pA84 = & (
( Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_5 [ 84 ] ; const
real_T * xc = & ( ( ContinuousStates_teste1 * ) ssGetContStates ( S ) ) ->
HinfinityController_CSTATE [ 0 ] ; real_T * dx6 = & ( (
StateDerivatives_teste1 * ) ssGetdX ( S ) ) -> HinfinityController_CSTATE [ 6
] ; int_T numNonZero = 13 ; * dx6 = ( * pA84 ++ ) * xc [ * pAidx ++ ] ; while
( numNonZero -- ) { * dx6 += ( * pA84 ++ ) * xc [ * pAidx ++ ] ; } } ( (
StateDerivatives_teste1 * ) ssGetdX ( S ) ) -> HinfinityController_CSTATE [ 6
] += ( ( ( Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_6 [ 12 ] ) *
( ( BlockIO_teste1 * ) _ssGetBlockIO ( S ) ) -> B_0_7_0 + ( ( (
Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_6 [ 13 ] ) * ( (
BlockIO_teste1 * ) _ssGetBlockIO ( S ) ) -> B_0_9_0 ; { static const int_T
colAidxRow7 [ 14 ] = { 0 , 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 , 10 , 11 , 12 ,
13 } ; const int_T * pAidx = & colAidxRow7 [ 0 ] ; const real_T * pA98 = & (
( Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_5 [ 98 ] ; const
real_T * xc = & ( ( ContinuousStates_teste1 * ) ssGetContStates ( S ) ) ->
HinfinityController_CSTATE [ 0 ] ; real_T * dx7 = & ( (
StateDerivatives_teste1 * ) ssGetdX ( S ) ) -> HinfinityController_CSTATE [ 7
] ; int_T numNonZero = 13 ; * dx7 = ( * pA98 ++ ) * xc [ * pAidx ++ ] ; while
( numNonZero -- ) { * dx7 += ( * pA98 ++ ) * xc [ * pAidx ++ ] ; } } ( (
StateDerivatives_teste1 * ) ssGetdX ( S ) ) -> HinfinityController_CSTATE [ 7
] += ( ( ( Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_6 [ 14 ] ) *
( ( BlockIO_teste1 * ) _ssGetBlockIO ( S ) ) -> B_0_7_0 + ( ( (
Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_6 [ 15 ] ) * ( (
BlockIO_teste1 * ) _ssGetBlockIO ( S ) ) -> B_0_9_0 ; { static const int_T
colAidxRow8 [ 14 ] = { 0 , 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 , 10 , 11 , 12 ,
13 } ; const int_T * pAidx = & colAidxRow8 [ 0 ] ; const real_T * pA112 = & (
( Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_5 [ 112 ] ; const
real_T * xc = & ( ( ContinuousStates_teste1 * ) ssGetContStates ( S ) ) ->
HinfinityController_CSTATE [ 0 ] ; real_T * dx8 = & ( (
StateDerivatives_teste1 * ) ssGetdX ( S ) ) -> HinfinityController_CSTATE [ 8
] ; int_T numNonZero = 13 ; * dx8 = ( * pA112 ++ ) * xc [ * pAidx ++ ] ;
while ( numNonZero -- ) { * dx8 += ( * pA112 ++ ) * xc [ * pAidx ++ ] ; } } (
( StateDerivatives_teste1 * ) ssGetdX ( S ) ) -> HinfinityController_CSTATE [
8 ] += ( ( ( Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_6 [ 16 ] )
* ( ( BlockIO_teste1 * ) _ssGetBlockIO ( S ) ) -> B_0_7_0 + ( ( (
Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_6 [ 17 ] ) * ( (
BlockIO_teste1 * ) _ssGetBlockIO ( S ) ) -> B_0_9_0 ; { static const int_T
colAidxRow9 [ 14 ] = { 0 , 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 , 10 , 11 , 12 ,
13 } ; const int_T * pAidx = & colAidxRow9 [ 0 ] ; const real_T * pA126 = & (
( Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_5 [ 126 ] ; const
real_T * xc = & ( ( ContinuousStates_teste1 * ) ssGetContStates ( S ) ) ->
HinfinityController_CSTATE [ 0 ] ; real_T * dx9 = & ( (
StateDerivatives_teste1 * ) ssGetdX ( S ) ) -> HinfinityController_CSTATE [ 9
] ; int_T numNonZero = 13 ; * dx9 = ( * pA126 ++ ) * xc [ * pAidx ++ ] ;
while ( numNonZero -- ) { * dx9 += ( * pA126 ++ ) * xc [ * pAidx ++ ] ; } } (
( StateDerivatives_teste1 * ) ssGetdX ( S ) ) -> HinfinityController_CSTATE [
9 ] += ( ( ( Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_6 [ 18 ] )
* ( ( BlockIO_teste1 * ) _ssGetBlockIO ( S ) ) -> B_0_7_0 + ( ( (
Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_6 [ 19 ] ) * ( (
BlockIO_teste1 * ) _ssGetBlockIO ( S ) ) -> B_0_9_0 ; { static const int_T
colAidxRow10 [ 14 ] = { 0 , 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 , 10 , 11 , 12
, 13 } ; const int_T * pAidx = & colAidxRow10 [ 0 ] ; const real_T * pA140 =
& ( ( Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_5 [ 140 ] ; const
real_T * xc = & ( ( ContinuousStates_teste1 * ) ssGetContStates ( S ) ) ->
HinfinityController_CSTATE [ 0 ] ; real_T * dx10 = & ( (
StateDerivatives_teste1 * ) ssGetdX ( S ) ) -> HinfinityController_CSTATE [
10 ] ; int_T numNonZero = 13 ; * dx10 = ( * pA140 ++ ) * xc [ * pAidx ++ ] ;
while ( numNonZero -- ) { * dx10 += ( * pA140 ++ ) * xc [ * pAidx ++ ] ; } }
( ( StateDerivatives_teste1 * ) ssGetdX ( S ) ) -> HinfinityController_CSTATE
[ 10 ] += ( ( ( Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_6 [ 20 ]
) * ( ( BlockIO_teste1 * ) _ssGetBlockIO ( S ) ) -> B_0_7_0 + ( ( (
Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_6 [ 21 ] ) * ( (
BlockIO_teste1 * ) _ssGetBlockIO ( S ) ) -> B_0_9_0 ; { static const int_T
colAidxRow11 [ 14 ] = { 0 , 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 , 10 , 11 , 12
, 13 } ; const int_T * pAidx = & colAidxRow11 [ 0 ] ; const real_T * pA154 =
& ( ( Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_5 [ 154 ] ; const
real_T * xc = & ( ( ContinuousStates_teste1 * ) ssGetContStates ( S ) ) ->
HinfinityController_CSTATE [ 0 ] ; real_T * dx11 = & ( (
StateDerivatives_teste1 * ) ssGetdX ( S ) ) -> HinfinityController_CSTATE [
11 ] ; int_T numNonZero = 13 ; * dx11 = ( * pA154 ++ ) * xc [ * pAidx ++ ] ;
while ( numNonZero -- ) { * dx11 += ( * pA154 ++ ) * xc [ * pAidx ++ ] ; } }
( ( StateDerivatives_teste1 * ) ssGetdX ( S ) ) -> HinfinityController_CSTATE
[ 11 ] += ( ( ( Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_6 [ 22 ]
) * ( ( BlockIO_teste1 * ) _ssGetBlockIO ( S ) ) -> B_0_7_0 + ( ( (
Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_6 [ 23 ] ) * ( (
BlockIO_teste1 * ) _ssGetBlockIO ( S ) ) -> B_0_9_0 ; { static const int_T
colAidxRow12 [ 14 ] = { 0 , 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 , 10 , 11 , 12
, 13 } ; const int_T * pAidx = & colAidxRow12 [ 0 ] ; const real_T * pA168 =
& ( ( Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_5 [ 168 ] ; const
real_T * xc = & ( ( ContinuousStates_teste1 * ) ssGetContStates ( S ) ) ->
HinfinityController_CSTATE [ 0 ] ; real_T * dx12 = & ( (
StateDerivatives_teste1 * ) ssGetdX ( S ) ) -> HinfinityController_CSTATE [
12 ] ; int_T numNonZero = 13 ; * dx12 = ( * pA168 ++ ) * xc [ * pAidx ++ ] ;
while ( numNonZero -- ) { * dx12 += ( * pA168 ++ ) * xc [ * pAidx ++ ] ; } }
( ( StateDerivatives_teste1 * ) ssGetdX ( S ) ) -> HinfinityController_CSTATE
[ 12 ] += ( ( ( Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_6 [ 24 ]
) * ( ( BlockIO_teste1 * ) _ssGetBlockIO ( S ) ) -> B_0_7_0 + ( ( (
Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_6 [ 25 ] ) * ( (
BlockIO_teste1 * ) _ssGetBlockIO ( S ) ) -> B_0_9_0 ; { static const int_T
colAidxRow13 [ 14 ] = { 0 , 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 , 10 , 11 , 12
, 13 } ; const int_T * pAidx = & colAidxRow13 [ 0 ] ; const real_T * pA182 =
& ( ( Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_5 [ 182 ] ; const
real_T * xc = & ( ( ContinuousStates_teste1 * ) ssGetContStates ( S ) ) ->
HinfinityController_CSTATE [ 0 ] ; real_T * dx13 = & ( (
StateDerivatives_teste1 * ) ssGetdX ( S ) ) -> HinfinityController_CSTATE [
13 ] ; int_T numNonZero = 13 ; * dx13 = ( * pA182 ++ ) * xc [ * pAidx ++ ] ;
while ( numNonZero -- ) { * dx13 += ( * pA182 ++ ) * xc [ * pAidx ++ ] ; } }
( ( StateDerivatives_teste1 * ) ssGetdX ( S ) ) -> HinfinityController_CSTATE
[ 13 ] += ( ( ( Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_6 [ 26 ]
) * ( ( BlockIO_teste1 * ) _ssGetBlockIO ( S ) ) -> B_0_7_0 + ( ( (
Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_6 [ 27 ] ) * ( (
BlockIO_teste1 * ) _ssGetBlockIO ( S ) ) -> B_0_9_0 ; } { ( (
StateDerivatives_teste1 * ) ssGetdX ( S ) ) -> StateSpace2_CSTATE [ 0 ] = ( (
( Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_12 [ 0 ] ) * ( (
ContinuousStates_teste1 * ) ssGetContStates ( S ) ) -> StateSpace2_CSTATE [ 0
] + ( ( ( Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_12 [ 1 ] ) * (
( ContinuousStates_teste1 * ) ssGetContStates ( S ) ) -> StateSpace2_CSTATE [
1 ] + ( ( ( Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_12 [ 2 ] ) *
( ( ContinuousStates_teste1 * ) ssGetContStates ( S ) ) -> StateSpace2_CSTATE
[ 2 ] ; ( ( StateDerivatives_teste1 * ) ssGetdX ( S ) ) -> StateSpace2_CSTATE
[ 0 ] += ( ( ( Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_13 [ 0 ]
) * ( ( BlockIO_teste1 * ) _ssGetBlockIO ( S ) ) -> B_0_13_0 [ 0 ] ; ( (
StateDerivatives_teste1 * ) ssGetdX ( S ) ) -> StateSpace2_CSTATE [ 1 ] = ( (
( Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_12 [ 3 ] ) * ( (
ContinuousStates_teste1 * ) ssGetContStates ( S ) ) -> StateSpace2_CSTATE [ 0
] + ( ( ( Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_12 [ 4 ] ) * (
( ContinuousStates_teste1 * ) ssGetContStates ( S ) ) -> StateSpace2_CSTATE [
1 ] + ( ( ( Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_12 [ 5 ] ) *
( ( ContinuousStates_teste1 * ) ssGetContStates ( S ) ) -> StateSpace2_CSTATE
[ 2 ] ; ( ( StateDerivatives_teste1 * ) ssGetdX ( S ) ) -> StateSpace2_CSTATE
[ 1 ] += ( ( ( Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_13 [ 1 ]
) * ( ( BlockIO_teste1 * ) _ssGetBlockIO ( S ) ) -> B_0_13_0 [ 1 ] ; ( (
StateDerivatives_teste1 * ) ssGetdX ( S ) ) -> StateSpace2_CSTATE [ 2 ] = ( (
( Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_12 [ 6 ] ) * ( (
ContinuousStates_teste1 * ) ssGetContStates ( S ) ) -> StateSpace2_CSTATE [ 0
] + ( ( ( Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_12 [ 7 ] ) * (
( ContinuousStates_teste1 * ) ssGetContStates ( S ) ) -> StateSpace2_CSTATE [
1 ] + ( ( ( Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_12 [ 8 ] ) *
( ( ContinuousStates_teste1 * ) ssGetContStates ( S ) ) -> StateSpace2_CSTATE
[ 2 ] ; ( ( StateDerivatives_teste1 * ) ssGetdX ( S ) ) -> StateSpace2_CSTATE
[ 2 ] += ( ( ( Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_13 [ 2 ]
) * ( ( BlockIO_teste1 * ) _ssGetBlockIO ( S ) ) -> B_0_13_0 [ 1 ] ; ( (
StateDerivatives_teste1 * ) ssGetdX ( S ) ) -> StateSpace2_CSTATE [ 3 ] = ( (
( Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_12 [ 9 ] ) * ( (
ContinuousStates_teste1 * ) ssGetContStates ( S ) ) -> StateSpace2_CSTATE [ 2
] ; } { { static const int_T colAidxRow0 [ 14 ] = { 0 , 1 , 2 , 3 , 4 , 5 , 6
, 7 , 8 , 9 , 10 , 11 , 12 , 13 } ; const int_T * pAidx = & colAidxRow0 [ 0 ]
; const real_T * pA0 = ( ( Parameters_teste1 * ) ssGetDefaultParam ( S ) ) ->
P_17 ; const real_T * xc = & ( ( ContinuousStates_teste1 * ) ssGetContStates
( S ) ) -> HinfinityController1_CSTATE [ 0 ] ; real_T * dx0 = & ( (
StateDerivatives_teste1 * ) ssGetdX ( S ) ) -> HinfinityController1_CSTATE [
0 ] ; int_T numNonZero = 13 ; * dx0 = ( * pA0 ++ ) * xc [ * pAidx ++ ] ;
while ( numNonZero -- ) { * dx0 += ( * pA0 ++ ) * xc [ * pAidx ++ ] ; } } ( (
StateDerivatives_teste1 * ) ssGetdX ( S ) ) -> HinfinityController1_CSTATE [
0 ] += ( ( ( Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_18 [ 0 ] )
* ( ( BlockIO_teste1 * ) _ssGetBlockIO ( S ) ) -> B_0_22_0 [ 0 ] + ( ( (
Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_18 [ 1 ] ) * ( (
BlockIO_teste1 * ) _ssGetBlockIO ( S ) ) -> B_0_22_0 [ 1 ] ; { static const
int_T colAidxRow1 [ 14 ] = { 0 , 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 , 10 , 11
, 12 , 13 } ; const int_T * pAidx = & colAidxRow1 [ 0 ] ; const real_T * pA14
= & ( ( Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_17 [ 14 ] ;
const real_T * xc = & ( ( ContinuousStates_teste1 * ) ssGetContStates ( S ) )
-> HinfinityController1_CSTATE [ 0 ] ; real_T * dx1 = & ( (
StateDerivatives_teste1 * ) ssGetdX ( S ) ) -> HinfinityController1_CSTATE [
1 ] ; int_T numNonZero = 13 ; * dx1 = ( * pA14 ++ ) * xc [ * pAidx ++ ] ;
while ( numNonZero -- ) { * dx1 += ( * pA14 ++ ) * xc [ * pAidx ++ ] ; } } (
( StateDerivatives_teste1 * ) ssGetdX ( S ) ) -> HinfinityController1_CSTATE
[ 1 ] += ( ( ( Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_18 [ 2 ]
) * ( ( BlockIO_teste1 * ) _ssGetBlockIO ( S ) ) -> B_0_22_0 [ 0 ] + ( ( (
Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_18 [ 3 ] ) * ( (
BlockIO_teste1 * ) _ssGetBlockIO ( S ) ) -> B_0_22_0 [ 1 ] ; { static const
int_T colAidxRow2 [ 14 ] = { 0 , 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 , 10 , 11
, 12 , 13 } ; const int_T * pAidx = & colAidxRow2 [ 0 ] ; const real_T * pA28
= & ( ( Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_17 [ 28 ] ;
const real_T * xc = & ( ( ContinuousStates_teste1 * ) ssGetContStates ( S ) )
-> HinfinityController1_CSTATE [ 0 ] ; real_T * dx2 = & ( (
StateDerivatives_teste1 * ) ssGetdX ( S ) ) -> HinfinityController1_CSTATE [
2 ] ; int_T numNonZero = 13 ; * dx2 = ( * pA28 ++ ) * xc [ * pAidx ++ ] ;
while ( numNonZero -- ) { * dx2 += ( * pA28 ++ ) * xc [ * pAidx ++ ] ; } } (
( StateDerivatives_teste1 * ) ssGetdX ( S ) ) -> HinfinityController1_CSTATE
[ 2 ] += ( ( ( Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_18 [ 4 ]
) * ( ( BlockIO_teste1 * ) _ssGetBlockIO ( S ) ) -> B_0_22_0 [ 0 ] + ( ( (
Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_18 [ 5 ] ) * ( (
BlockIO_teste1 * ) _ssGetBlockIO ( S ) ) -> B_0_22_0 [ 1 ] ; { static const
int_T colAidxRow3 [ 14 ] = { 0 , 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 , 10 , 11
, 12 , 13 } ; const int_T * pAidx = & colAidxRow3 [ 0 ] ; const real_T * pA42
= & ( ( Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_17 [ 42 ] ;
const real_T * xc = & ( ( ContinuousStates_teste1 * ) ssGetContStates ( S ) )
-> HinfinityController1_CSTATE [ 0 ] ; real_T * dx3 = & ( (
StateDerivatives_teste1 * ) ssGetdX ( S ) ) -> HinfinityController1_CSTATE [
3 ] ; int_T numNonZero = 13 ; * dx3 = ( * pA42 ++ ) * xc [ * pAidx ++ ] ;
while ( numNonZero -- ) { * dx3 += ( * pA42 ++ ) * xc [ * pAidx ++ ] ; } } (
( StateDerivatives_teste1 * ) ssGetdX ( S ) ) -> HinfinityController1_CSTATE
[ 3 ] += ( ( ( Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_18 [ 6 ]
) * ( ( BlockIO_teste1 * ) _ssGetBlockIO ( S ) ) -> B_0_22_0 [ 0 ] + ( ( (
Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_18 [ 7 ] ) * ( (
BlockIO_teste1 * ) _ssGetBlockIO ( S ) ) -> B_0_22_0 [ 1 ] ; { static const
int_T colAidxRow4 [ 14 ] = { 0 , 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 , 10 , 11
, 12 , 13 } ; const int_T * pAidx = & colAidxRow4 [ 0 ] ; const real_T * pA56
= & ( ( Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_17 [ 56 ] ;
const real_T * xc = & ( ( ContinuousStates_teste1 * ) ssGetContStates ( S ) )
-> HinfinityController1_CSTATE [ 0 ] ; real_T * dx4 = & ( (
StateDerivatives_teste1 * ) ssGetdX ( S ) ) -> HinfinityController1_CSTATE [
4 ] ; int_T numNonZero = 13 ; * dx4 = ( * pA56 ++ ) * xc [ * pAidx ++ ] ;
while ( numNonZero -- ) { * dx4 += ( * pA56 ++ ) * xc [ * pAidx ++ ] ; } } (
( StateDerivatives_teste1 * ) ssGetdX ( S ) ) -> HinfinityController1_CSTATE
[ 4 ] += ( ( ( Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_18 [ 8 ]
) * ( ( BlockIO_teste1 * ) _ssGetBlockIO ( S ) ) -> B_0_22_0 [ 0 ] + ( ( (
Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_18 [ 9 ] ) * ( (
BlockIO_teste1 * ) _ssGetBlockIO ( S ) ) -> B_0_22_0 [ 1 ] ; { static const
int_T colAidxRow5 [ 14 ] = { 0 , 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 , 10 , 11
, 12 , 13 } ; const int_T * pAidx = & colAidxRow5 [ 0 ] ; const real_T * pA70
= & ( ( Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_17 [ 70 ] ;
const real_T * xc = & ( ( ContinuousStates_teste1 * ) ssGetContStates ( S ) )
-> HinfinityController1_CSTATE [ 0 ] ; real_T * dx5 = & ( (
StateDerivatives_teste1 * ) ssGetdX ( S ) ) -> HinfinityController1_CSTATE [
5 ] ; int_T numNonZero = 13 ; * dx5 = ( * pA70 ++ ) * xc [ * pAidx ++ ] ;
while ( numNonZero -- ) { * dx5 += ( * pA70 ++ ) * xc [ * pAidx ++ ] ; } } (
( StateDerivatives_teste1 * ) ssGetdX ( S ) ) -> HinfinityController1_CSTATE
[ 5 ] += ( ( ( Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_18 [ 10 ]
) * ( ( BlockIO_teste1 * ) _ssGetBlockIO ( S ) ) -> B_0_22_0 [ 0 ] + ( ( (
Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_18 [ 11 ] ) * ( (
BlockIO_teste1 * ) _ssGetBlockIO ( S ) ) -> B_0_22_0 [ 1 ] ; { static const
int_T colAidxRow6 [ 14 ] = { 0 , 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 , 10 , 11
, 12 , 13 } ; const int_T * pAidx = & colAidxRow6 [ 0 ] ; const real_T * pA84
= & ( ( Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_17 [ 84 ] ;
const real_T * xc = & ( ( ContinuousStates_teste1 * ) ssGetContStates ( S ) )
-> HinfinityController1_CSTATE [ 0 ] ; real_T * dx6 = & ( (
StateDerivatives_teste1 * ) ssGetdX ( S ) ) -> HinfinityController1_CSTATE [
6 ] ; int_T numNonZero = 13 ; * dx6 = ( * pA84 ++ ) * xc [ * pAidx ++ ] ;
while ( numNonZero -- ) { * dx6 += ( * pA84 ++ ) * xc [ * pAidx ++ ] ; } } (
( StateDerivatives_teste1 * ) ssGetdX ( S ) ) -> HinfinityController1_CSTATE
[ 6 ] += ( ( ( Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_18 [ 12 ]
) * ( ( BlockIO_teste1 * ) _ssGetBlockIO ( S ) ) -> B_0_22_0 [ 0 ] + ( ( (
Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_18 [ 13 ] ) * ( (
BlockIO_teste1 * ) _ssGetBlockIO ( S ) ) -> B_0_22_0 [ 1 ] ; { static const
int_T colAidxRow7 [ 14 ] = { 0 , 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 , 10 , 11
, 12 , 13 } ; const int_T * pAidx = & colAidxRow7 [ 0 ] ; const real_T * pA98
= & ( ( Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_17 [ 98 ] ;
const real_T * xc = & ( ( ContinuousStates_teste1 * ) ssGetContStates ( S ) )
-> HinfinityController1_CSTATE [ 0 ] ; real_T * dx7 = & ( (
StateDerivatives_teste1 * ) ssGetdX ( S ) ) -> HinfinityController1_CSTATE [
7 ] ; int_T numNonZero = 13 ; * dx7 = ( * pA98 ++ ) * xc [ * pAidx ++ ] ;
while ( numNonZero -- ) { * dx7 += ( * pA98 ++ ) * xc [ * pAidx ++ ] ; } } (
( StateDerivatives_teste1 * ) ssGetdX ( S ) ) -> HinfinityController1_CSTATE
[ 7 ] += ( ( ( Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_18 [ 14 ]
) * ( ( BlockIO_teste1 * ) _ssGetBlockIO ( S ) ) -> B_0_22_0 [ 0 ] + ( ( (
Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_18 [ 15 ] ) * ( (
BlockIO_teste1 * ) _ssGetBlockIO ( S ) ) -> B_0_22_0 [ 1 ] ; { static const
int_T colAidxRow8 [ 14 ] = { 0 , 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 , 10 , 11
, 12 , 13 } ; const int_T * pAidx = & colAidxRow8 [ 0 ] ; const real_T *
pA112 = & ( ( Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_17 [ 112 ]
; const real_T * xc = & ( ( ContinuousStates_teste1 * ) ssGetContStates ( S )
) -> HinfinityController1_CSTATE [ 0 ] ; real_T * dx8 = & ( (
StateDerivatives_teste1 * ) ssGetdX ( S ) ) -> HinfinityController1_CSTATE [
8 ] ; int_T numNonZero = 13 ; * dx8 = ( * pA112 ++ ) * xc [ * pAidx ++ ] ;
while ( numNonZero -- ) { * dx8 += ( * pA112 ++ ) * xc [ * pAidx ++ ] ; } } (
( StateDerivatives_teste1 * ) ssGetdX ( S ) ) -> HinfinityController1_CSTATE
[ 8 ] += ( ( ( Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_18 [ 16 ]
) * ( ( BlockIO_teste1 * ) _ssGetBlockIO ( S ) ) -> B_0_22_0 [ 0 ] + ( ( (
Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_18 [ 17 ] ) * ( (
BlockIO_teste1 * ) _ssGetBlockIO ( S ) ) -> B_0_22_0 [ 1 ] ; { static const
int_T colAidxRow9 [ 14 ] = { 0 , 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 , 10 , 11
, 12 , 13 } ; const int_T * pAidx = & colAidxRow9 [ 0 ] ; const real_T *
pA126 = & ( ( Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_17 [ 126 ]
; const real_T * xc = & ( ( ContinuousStates_teste1 * ) ssGetContStates ( S )
) -> HinfinityController1_CSTATE [ 0 ] ; real_T * dx9 = & ( (
StateDerivatives_teste1 * ) ssGetdX ( S ) ) -> HinfinityController1_CSTATE [
9 ] ; int_T numNonZero = 13 ; * dx9 = ( * pA126 ++ ) * xc [ * pAidx ++ ] ;
while ( numNonZero -- ) { * dx9 += ( * pA126 ++ ) * xc [ * pAidx ++ ] ; } } (
( StateDerivatives_teste1 * ) ssGetdX ( S ) ) -> HinfinityController1_CSTATE
[ 9 ] += ( ( ( Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_18 [ 18 ]
) * ( ( BlockIO_teste1 * ) _ssGetBlockIO ( S ) ) -> B_0_22_0 [ 0 ] + ( ( (
Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_18 [ 19 ] ) * ( (
BlockIO_teste1 * ) _ssGetBlockIO ( S ) ) -> B_0_22_0 [ 1 ] ; { static const
int_T colAidxRow10 [ 14 ] = { 0 , 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 , 10 , 11
, 12 , 13 } ; const int_T * pAidx = & colAidxRow10 [ 0 ] ; const real_T *
pA140 = & ( ( Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_17 [ 140 ]
; const real_T * xc = & ( ( ContinuousStates_teste1 * ) ssGetContStates ( S )
) -> HinfinityController1_CSTATE [ 0 ] ; real_T * dx10 = & ( (
StateDerivatives_teste1 * ) ssGetdX ( S ) ) -> HinfinityController1_CSTATE [
10 ] ; int_T numNonZero = 13 ; * dx10 = ( * pA140 ++ ) * xc [ * pAidx ++ ] ;
while ( numNonZero -- ) { * dx10 += ( * pA140 ++ ) * xc [ * pAidx ++ ] ; } }
( ( StateDerivatives_teste1 * ) ssGetdX ( S ) ) ->
HinfinityController1_CSTATE [ 10 ] += ( ( ( Parameters_teste1 * )
ssGetDefaultParam ( S ) ) -> P_18 [ 20 ] ) * ( ( BlockIO_teste1 * )
_ssGetBlockIO ( S ) ) -> B_0_22_0 [ 0 ] + ( ( ( Parameters_teste1 * )
ssGetDefaultParam ( S ) ) -> P_18 [ 21 ] ) * ( ( BlockIO_teste1 * )
_ssGetBlockIO ( S ) ) -> B_0_22_0 [ 1 ] ; { static const int_T colAidxRow11 [
14 ] = { 0 , 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 , 10 , 11 , 12 , 13 } ; const
int_T * pAidx = & colAidxRow11 [ 0 ] ; const real_T * pA154 = & ( (
Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_17 [ 154 ] ; const
real_T * xc = & ( ( ContinuousStates_teste1 * ) ssGetContStates ( S ) ) ->
HinfinityController1_CSTATE [ 0 ] ; real_T * dx11 = & ( (
StateDerivatives_teste1 * ) ssGetdX ( S ) ) -> HinfinityController1_CSTATE [
11 ] ; int_T numNonZero = 13 ; * dx11 = ( * pA154 ++ ) * xc [ * pAidx ++ ] ;
while ( numNonZero -- ) { * dx11 += ( * pA154 ++ ) * xc [ * pAidx ++ ] ; } }
( ( StateDerivatives_teste1 * ) ssGetdX ( S ) ) ->
HinfinityController1_CSTATE [ 11 ] += ( ( ( Parameters_teste1 * )
ssGetDefaultParam ( S ) ) -> P_18 [ 22 ] ) * ( ( BlockIO_teste1 * )
_ssGetBlockIO ( S ) ) -> B_0_22_0 [ 0 ] + ( ( ( Parameters_teste1 * )
ssGetDefaultParam ( S ) ) -> P_18 [ 23 ] ) * ( ( BlockIO_teste1 * )
_ssGetBlockIO ( S ) ) -> B_0_22_0 [ 1 ] ; { static const int_T colAidxRow12 [
14 ] = { 0 , 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 , 10 , 11 , 12 , 13 } ; const
int_T * pAidx = & colAidxRow12 [ 0 ] ; const real_T * pA168 = & ( (
Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_17 [ 168 ] ; const
real_T * xc = & ( ( ContinuousStates_teste1 * ) ssGetContStates ( S ) ) ->
HinfinityController1_CSTATE [ 0 ] ; real_T * dx12 = & ( (
StateDerivatives_teste1 * ) ssGetdX ( S ) ) -> HinfinityController1_CSTATE [
12 ] ; int_T numNonZero = 13 ; * dx12 = ( * pA168 ++ ) * xc [ * pAidx ++ ] ;
while ( numNonZero -- ) { * dx12 += ( * pA168 ++ ) * xc [ * pAidx ++ ] ; } }
( ( StateDerivatives_teste1 * ) ssGetdX ( S ) ) ->
HinfinityController1_CSTATE [ 12 ] += ( ( ( Parameters_teste1 * )
ssGetDefaultParam ( S ) ) -> P_18 [ 24 ] ) * ( ( BlockIO_teste1 * )
_ssGetBlockIO ( S ) ) -> B_0_22_0 [ 0 ] + ( ( ( Parameters_teste1 * )
ssGetDefaultParam ( S ) ) -> P_18 [ 25 ] ) * ( ( BlockIO_teste1 * )
_ssGetBlockIO ( S ) ) -> B_0_22_0 [ 1 ] ; { static const int_T colAidxRow13 [
14 ] = { 0 , 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 , 10 , 11 , 12 , 13 } ; const
int_T * pAidx = & colAidxRow13 [ 0 ] ; const real_T * pA182 = & ( (
Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_17 [ 182 ] ; const
real_T * xc = & ( ( ContinuousStates_teste1 * ) ssGetContStates ( S ) ) ->
HinfinityController1_CSTATE [ 0 ] ; real_T * dx13 = & ( (
StateDerivatives_teste1 * ) ssGetdX ( S ) ) -> HinfinityController1_CSTATE [
13 ] ; int_T numNonZero = 13 ; * dx13 = ( * pA182 ++ ) * xc [ * pAidx ++ ] ;
while ( numNonZero -- ) { * dx13 += ( * pA182 ++ ) * xc [ * pAidx ++ ] ; } }
( ( StateDerivatives_teste1 * ) ssGetdX ( S ) ) ->
HinfinityController1_CSTATE [ 13 ] += ( ( ( Parameters_teste1 * )
ssGetDefaultParam ( S ) ) -> P_18 [ 26 ] ) * ( ( BlockIO_teste1 * )
_ssGetBlockIO ( S ) ) -> B_0_22_0 [ 0 ] + ( ( ( Parameters_teste1 * )
ssGetDefaultParam ( S ) ) -> P_18 [ 27 ] ) * ( ( BlockIO_teste1 * )
_ssGetBlockIO ( S ) ) -> B_0_22_0 [ 1 ] ; } { { int_T i1 ; const real_T * u0
= ( ( BlockIO_teste1 * ) _ssGetBlockIO ( S ) ) -> B_0_31_0 ; real_T * xdot =
& ( ( StateDerivatives_teste1 * ) ssGetdX ( S ) ) -> Integrator_CSTATE [ 0 ]
; for ( i1 = 0 ; i1 < 6 ; i1 ++ ) { xdot [ i1 ] = u0 [ i1 ] ; } } } { {
static const int_T colAidxRow0 [ 14 ] = { 0 , 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 ,
9 , 10 , 11 , 12 , 13 } ; const int_T * pAidx = & colAidxRow0 [ 0 ] ; const
real_T * pA0 = ( ( Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_27 ;
const real_T * xc = & ( ( ContinuousStates_teste1 * ) ssGetContStates ( S ) )
-> HinfinityController2_CSTATE [ 0 ] ; real_T * dx0 = & ( (
StateDerivatives_teste1 * ) ssGetdX ( S ) ) -> HinfinityController2_CSTATE [
0 ] ; int_T numNonZero = 13 ; * dx0 = ( * pA0 ++ ) * xc [ * pAidx ++ ] ;
while ( numNonZero -- ) { * dx0 += ( * pA0 ++ ) * xc [ * pAidx ++ ] ; } } ( (
StateDerivatives_teste1 * ) ssGetdX ( S ) ) -> HinfinityController2_CSTATE [
0 ] += ( ( ( Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_28 [ 0 ] )
* ( ( BlockIO_teste1 * ) _ssGetBlockIO ( S ) ) -> B_0_37_0 [ 0 ] + ( ( (
Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_28 [ 1 ] ) * ( (
BlockIO_teste1 * ) _ssGetBlockIO ( S ) ) -> B_0_37_0 [ 1 ] ; { static const
int_T colAidxRow1 [ 14 ] = { 0 , 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 , 10 , 11
, 12 , 13 } ; const int_T * pAidx = & colAidxRow1 [ 0 ] ; const real_T * pA14
= & ( ( Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_27 [ 14 ] ;
const real_T * xc = & ( ( ContinuousStates_teste1 * ) ssGetContStates ( S ) )
-> HinfinityController2_CSTATE [ 0 ] ; real_T * dx1 = & ( (
StateDerivatives_teste1 * ) ssGetdX ( S ) ) -> HinfinityController2_CSTATE [
1 ] ; int_T numNonZero = 13 ; * dx1 = ( * pA14 ++ ) * xc [ * pAidx ++ ] ;
while ( numNonZero -- ) { * dx1 += ( * pA14 ++ ) * xc [ * pAidx ++ ] ; } } (
( StateDerivatives_teste1 * ) ssGetdX ( S ) ) -> HinfinityController2_CSTATE
[ 1 ] += ( ( ( Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_28 [ 2 ]
) * ( ( BlockIO_teste1 * ) _ssGetBlockIO ( S ) ) -> B_0_37_0 [ 0 ] + ( ( (
Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_28 [ 3 ] ) * ( (
BlockIO_teste1 * ) _ssGetBlockIO ( S ) ) -> B_0_37_0 [ 1 ] ; { static const
int_T colAidxRow2 [ 14 ] = { 0 , 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 , 10 , 11
, 12 , 13 } ; const int_T * pAidx = & colAidxRow2 [ 0 ] ; const real_T * pA28
= & ( ( Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_27 [ 28 ] ;
const real_T * xc = & ( ( ContinuousStates_teste1 * ) ssGetContStates ( S ) )
-> HinfinityController2_CSTATE [ 0 ] ; real_T * dx2 = & ( (
StateDerivatives_teste1 * ) ssGetdX ( S ) ) -> HinfinityController2_CSTATE [
2 ] ; int_T numNonZero = 13 ; * dx2 = ( * pA28 ++ ) * xc [ * pAidx ++ ] ;
while ( numNonZero -- ) { * dx2 += ( * pA28 ++ ) * xc [ * pAidx ++ ] ; } } (
( StateDerivatives_teste1 * ) ssGetdX ( S ) ) -> HinfinityController2_CSTATE
[ 2 ] += ( ( ( Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_28 [ 4 ]
) * ( ( BlockIO_teste1 * ) _ssGetBlockIO ( S ) ) -> B_0_37_0 [ 0 ] + ( ( (
Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_28 [ 5 ] ) * ( (
BlockIO_teste1 * ) _ssGetBlockIO ( S ) ) -> B_0_37_0 [ 1 ] ; { static const
int_T colAidxRow3 [ 14 ] = { 0 , 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 , 10 , 11
, 12 , 13 } ; const int_T * pAidx = & colAidxRow3 [ 0 ] ; const real_T * pA42
= & ( ( Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_27 [ 42 ] ;
const real_T * xc = & ( ( ContinuousStates_teste1 * ) ssGetContStates ( S ) )
-> HinfinityController2_CSTATE [ 0 ] ; real_T * dx3 = & ( (
StateDerivatives_teste1 * ) ssGetdX ( S ) ) -> HinfinityController2_CSTATE [
3 ] ; int_T numNonZero = 13 ; * dx3 = ( * pA42 ++ ) * xc [ * pAidx ++ ] ;
while ( numNonZero -- ) { * dx3 += ( * pA42 ++ ) * xc [ * pAidx ++ ] ; } } (
( StateDerivatives_teste1 * ) ssGetdX ( S ) ) -> HinfinityController2_CSTATE
[ 3 ] += ( ( ( Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_28 [ 6 ]
) * ( ( BlockIO_teste1 * ) _ssGetBlockIO ( S ) ) -> B_0_37_0 [ 0 ] + ( ( (
Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_28 [ 7 ] ) * ( (
BlockIO_teste1 * ) _ssGetBlockIO ( S ) ) -> B_0_37_0 [ 1 ] ; { static const
int_T colAidxRow4 [ 14 ] = { 0 , 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 , 10 , 11
, 12 , 13 } ; const int_T * pAidx = & colAidxRow4 [ 0 ] ; const real_T * pA56
= & ( ( Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_27 [ 56 ] ;
const real_T * xc = & ( ( ContinuousStates_teste1 * ) ssGetContStates ( S ) )
-> HinfinityController2_CSTATE [ 0 ] ; real_T * dx4 = & ( (
StateDerivatives_teste1 * ) ssGetdX ( S ) ) -> HinfinityController2_CSTATE [
4 ] ; int_T numNonZero = 13 ; * dx4 = ( * pA56 ++ ) * xc [ * pAidx ++ ] ;
while ( numNonZero -- ) { * dx4 += ( * pA56 ++ ) * xc [ * pAidx ++ ] ; } } (
( StateDerivatives_teste1 * ) ssGetdX ( S ) ) -> HinfinityController2_CSTATE
[ 4 ] += ( ( ( Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_28 [ 8 ]
) * ( ( BlockIO_teste1 * ) _ssGetBlockIO ( S ) ) -> B_0_37_0 [ 0 ] + ( ( (
Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_28 [ 9 ] ) * ( (
BlockIO_teste1 * ) _ssGetBlockIO ( S ) ) -> B_0_37_0 [ 1 ] ; { static const
int_T colAidxRow5 [ 14 ] = { 0 , 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 , 10 , 11
, 12 , 13 } ; const int_T * pAidx = & colAidxRow5 [ 0 ] ; const real_T * pA70
= & ( ( Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_27 [ 70 ] ;
const real_T * xc = & ( ( ContinuousStates_teste1 * ) ssGetContStates ( S ) )
-> HinfinityController2_CSTATE [ 0 ] ; real_T * dx5 = & ( (
StateDerivatives_teste1 * ) ssGetdX ( S ) ) -> HinfinityController2_CSTATE [
5 ] ; int_T numNonZero = 13 ; * dx5 = ( * pA70 ++ ) * xc [ * pAidx ++ ] ;
while ( numNonZero -- ) { * dx5 += ( * pA70 ++ ) * xc [ * pAidx ++ ] ; } } (
( StateDerivatives_teste1 * ) ssGetdX ( S ) ) -> HinfinityController2_CSTATE
[ 5 ] += ( ( ( Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_28 [ 10 ]
) * ( ( BlockIO_teste1 * ) _ssGetBlockIO ( S ) ) -> B_0_37_0 [ 0 ] + ( ( (
Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_28 [ 11 ] ) * ( (
BlockIO_teste1 * ) _ssGetBlockIO ( S ) ) -> B_0_37_0 [ 1 ] ; { static const
int_T colAidxRow6 [ 14 ] = { 0 , 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 , 10 , 11
, 12 , 13 } ; const int_T * pAidx = & colAidxRow6 [ 0 ] ; const real_T * pA84
= & ( ( Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_27 [ 84 ] ;
const real_T * xc = & ( ( ContinuousStates_teste1 * ) ssGetContStates ( S ) )
-> HinfinityController2_CSTATE [ 0 ] ; real_T * dx6 = & ( (
StateDerivatives_teste1 * ) ssGetdX ( S ) ) -> HinfinityController2_CSTATE [
6 ] ; int_T numNonZero = 13 ; * dx6 = ( * pA84 ++ ) * xc [ * pAidx ++ ] ;
while ( numNonZero -- ) { * dx6 += ( * pA84 ++ ) * xc [ * pAidx ++ ] ; } } (
( StateDerivatives_teste1 * ) ssGetdX ( S ) ) -> HinfinityController2_CSTATE
[ 6 ] += ( ( ( Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_28 [ 12 ]
) * ( ( BlockIO_teste1 * ) _ssGetBlockIO ( S ) ) -> B_0_37_0 [ 0 ] + ( ( (
Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_28 [ 13 ] ) * ( (
BlockIO_teste1 * ) _ssGetBlockIO ( S ) ) -> B_0_37_0 [ 1 ] ; { static const
int_T colAidxRow7 [ 14 ] = { 0 , 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 , 10 , 11
, 12 , 13 } ; const int_T * pAidx = & colAidxRow7 [ 0 ] ; const real_T * pA98
= & ( ( Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_27 [ 98 ] ;
const real_T * xc = & ( ( ContinuousStates_teste1 * ) ssGetContStates ( S ) )
-> HinfinityController2_CSTATE [ 0 ] ; real_T * dx7 = & ( (
StateDerivatives_teste1 * ) ssGetdX ( S ) ) -> HinfinityController2_CSTATE [
7 ] ; int_T numNonZero = 13 ; * dx7 = ( * pA98 ++ ) * xc [ * pAidx ++ ] ;
while ( numNonZero -- ) { * dx7 += ( * pA98 ++ ) * xc [ * pAidx ++ ] ; } } (
( StateDerivatives_teste1 * ) ssGetdX ( S ) ) -> HinfinityController2_CSTATE
[ 7 ] += ( ( ( Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_28 [ 14 ]
) * ( ( BlockIO_teste1 * ) _ssGetBlockIO ( S ) ) -> B_0_37_0 [ 0 ] + ( ( (
Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_28 [ 15 ] ) * ( (
BlockIO_teste1 * ) _ssGetBlockIO ( S ) ) -> B_0_37_0 [ 1 ] ; { static const
int_T colAidxRow8 [ 14 ] = { 0 , 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 , 10 , 11
, 12 , 13 } ; const int_T * pAidx = & colAidxRow8 [ 0 ] ; const real_T *
pA112 = & ( ( Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_27 [ 112 ]
; const real_T * xc = & ( ( ContinuousStates_teste1 * ) ssGetContStates ( S )
) -> HinfinityController2_CSTATE [ 0 ] ; real_T * dx8 = & ( (
StateDerivatives_teste1 * ) ssGetdX ( S ) ) -> HinfinityController2_CSTATE [
8 ] ; int_T numNonZero = 13 ; * dx8 = ( * pA112 ++ ) * xc [ * pAidx ++ ] ;
while ( numNonZero -- ) { * dx8 += ( * pA112 ++ ) * xc [ * pAidx ++ ] ; } } (
( StateDerivatives_teste1 * ) ssGetdX ( S ) ) -> HinfinityController2_CSTATE
[ 8 ] += ( ( ( Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_28 [ 16 ]
) * ( ( BlockIO_teste1 * ) _ssGetBlockIO ( S ) ) -> B_0_37_0 [ 0 ] + ( ( (
Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_28 [ 17 ] ) * ( (
BlockIO_teste1 * ) _ssGetBlockIO ( S ) ) -> B_0_37_0 [ 1 ] ; { static const
int_T colAidxRow9 [ 14 ] = { 0 , 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 , 10 , 11
, 12 , 13 } ; const int_T * pAidx = & colAidxRow9 [ 0 ] ; const real_T *
pA126 = & ( ( Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_27 [ 126 ]
; const real_T * xc = & ( ( ContinuousStates_teste1 * ) ssGetContStates ( S )
) -> HinfinityController2_CSTATE [ 0 ] ; real_T * dx9 = & ( (
StateDerivatives_teste1 * ) ssGetdX ( S ) ) -> HinfinityController2_CSTATE [
9 ] ; int_T numNonZero = 13 ; * dx9 = ( * pA126 ++ ) * xc [ * pAidx ++ ] ;
while ( numNonZero -- ) { * dx9 += ( * pA126 ++ ) * xc [ * pAidx ++ ] ; } } (
( StateDerivatives_teste1 * ) ssGetdX ( S ) ) -> HinfinityController2_CSTATE
[ 9 ] += ( ( ( Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_28 [ 18 ]
) * ( ( BlockIO_teste1 * ) _ssGetBlockIO ( S ) ) -> B_0_37_0 [ 0 ] + ( ( (
Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_28 [ 19 ] ) * ( (
BlockIO_teste1 * ) _ssGetBlockIO ( S ) ) -> B_0_37_0 [ 1 ] ; { static const
int_T colAidxRow10 [ 14 ] = { 0 , 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 , 10 , 11
, 12 , 13 } ; const int_T * pAidx = & colAidxRow10 [ 0 ] ; const real_T *
pA140 = & ( ( Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_27 [ 140 ]
; const real_T * xc = & ( ( ContinuousStates_teste1 * ) ssGetContStates ( S )
) -> HinfinityController2_CSTATE [ 0 ] ; real_T * dx10 = & ( (
StateDerivatives_teste1 * ) ssGetdX ( S ) ) -> HinfinityController2_CSTATE [
10 ] ; int_T numNonZero = 13 ; * dx10 = ( * pA140 ++ ) * xc [ * pAidx ++ ] ;
while ( numNonZero -- ) { * dx10 += ( * pA140 ++ ) * xc [ * pAidx ++ ] ; } }
( ( StateDerivatives_teste1 * ) ssGetdX ( S ) ) ->
HinfinityController2_CSTATE [ 10 ] += ( ( ( Parameters_teste1 * )
ssGetDefaultParam ( S ) ) -> P_28 [ 20 ] ) * ( ( BlockIO_teste1 * )
_ssGetBlockIO ( S ) ) -> B_0_37_0 [ 0 ] + ( ( ( Parameters_teste1 * )
ssGetDefaultParam ( S ) ) -> P_28 [ 21 ] ) * ( ( BlockIO_teste1 * )
_ssGetBlockIO ( S ) ) -> B_0_37_0 [ 1 ] ; { static const int_T colAidxRow11 [
14 ] = { 0 , 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 , 10 , 11 , 12 , 13 } ; const
int_T * pAidx = & colAidxRow11 [ 0 ] ; const real_T * pA154 = & ( (
Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_27 [ 154 ] ; const
real_T * xc = & ( ( ContinuousStates_teste1 * ) ssGetContStates ( S ) ) ->
HinfinityController2_CSTATE [ 0 ] ; real_T * dx11 = & ( (
StateDerivatives_teste1 * ) ssGetdX ( S ) ) -> HinfinityController2_CSTATE [
11 ] ; int_T numNonZero = 13 ; * dx11 = ( * pA154 ++ ) * xc [ * pAidx ++ ] ;
while ( numNonZero -- ) { * dx11 += ( * pA154 ++ ) * xc [ * pAidx ++ ] ; } }
( ( StateDerivatives_teste1 * ) ssGetdX ( S ) ) ->
HinfinityController2_CSTATE [ 11 ] += ( ( ( Parameters_teste1 * )
ssGetDefaultParam ( S ) ) -> P_28 [ 22 ] ) * ( ( BlockIO_teste1 * )
_ssGetBlockIO ( S ) ) -> B_0_37_0 [ 0 ] + ( ( ( Parameters_teste1 * )
ssGetDefaultParam ( S ) ) -> P_28 [ 23 ] ) * ( ( BlockIO_teste1 * )
_ssGetBlockIO ( S ) ) -> B_0_37_0 [ 1 ] ; { static const int_T colAidxRow12 [
14 ] = { 0 , 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 , 10 , 11 , 12 , 13 } ; const
int_T * pAidx = & colAidxRow12 [ 0 ] ; const real_T * pA168 = & ( (
Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_27 [ 168 ] ; const
real_T * xc = & ( ( ContinuousStates_teste1 * ) ssGetContStates ( S ) ) ->
HinfinityController2_CSTATE [ 0 ] ; real_T * dx12 = & ( (
StateDerivatives_teste1 * ) ssGetdX ( S ) ) -> HinfinityController2_CSTATE [
12 ] ; int_T numNonZero = 13 ; * dx12 = ( * pA168 ++ ) * xc [ * pAidx ++ ] ;
while ( numNonZero -- ) { * dx12 += ( * pA168 ++ ) * xc [ * pAidx ++ ] ; } }
( ( StateDerivatives_teste1 * ) ssGetdX ( S ) ) ->
HinfinityController2_CSTATE [ 12 ] += ( ( ( Parameters_teste1 * )
ssGetDefaultParam ( S ) ) -> P_28 [ 24 ] ) * ( ( BlockIO_teste1 * )
_ssGetBlockIO ( S ) ) -> B_0_37_0 [ 0 ] + ( ( ( Parameters_teste1 * )
ssGetDefaultParam ( S ) ) -> P_28 [ 25 ] ) * ( ( BlockIO_teste1 * )
_ssGetBlockIO ( S ) ) -> B_0_37_0 [ 1 ] ; { static const int_T colAidxRow13 [
14 ] = { 0 , 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 , 10 , 11 , 12 , 13 } ; const
int_T * pAidx = & colAidxRow13 [ 0 ] ; const real_T * pA182 = & ( (
Parameters_teste1 * ) ssGetDefaultParam ( S ) ) -> P_27 [ 182 ] ; const
real_T * xc = & ( ( ContinuousStates_teste1 * ) ssGetContStates ( S ) ) ->
HinfinityController2_CSTATE [ 0 ] ; real_T * dx13 = & ( (
StateDerivatives_teste1 * ) ssGetdX ( S ) ) -> HinfinityController2_CSTATE [
13 ] ; int_T numNonZero = 13 ; * dx13 = ( * pA182 ++ ) * xc [ * pAidx ++ ] ;
while ( numNonZero -- ) { * dx13 += ( * pA182 ++ ) * xc [ * pAidx ++ ] ; } }
( ( StateDerivatives_teste1 * ) ssGetdX ( S ) ) ->
HinfinityController2_CSTATE [ 13 ] += ( ( ( Parameters_teste1 * )
ssGetDefaultParam ( S ) ) -> P_28 [ 26 ] ) * ( ( BlockIO_teste1 * )
_ssGetBlockIO ( S ) ) -> B_0_37_0 [ 0 ] + ( ( ( Parameters_teste1 * )
ssGetDefaultParam ( S ) ) -> P_28 [ 27 ] ) * ( ( BlockIO_teste1 * )
_ssGetBlockIO ( S ) ) -> B_0_37_0 [ 1 ] ; } } static void mdlInitializeSizes
( SimStruct * S ) { ssSetChecksumVal ( S , 0 , 2249671258U ) ;
ssSetChecksumVal ( S , 1 , 1739282423U ) ; ssSetChecksumVal ( S , 2 ,
1109815417U ) ; ssSetChecksumVal ( S , 3 , 2082193856U ) ; { mxArray *
slVerStructMat = NULL ; mxArray * slStrMat = mxCreateString ( "simulink" ) ;
char slVerChar [ 10 ] ; int status = mexCallMATLAB ( 1 , & slVerStructMat , 1
, & slStrMat , "ver" ) ; if ( status == 0 ) { mxArray * slVerMat = mxGetField
( slVerStructMat , 0 , "Version" ) ; if ( slVerMat == NULL ) { status = 1 ; }
else { status = mxGetString ( slVerMat , slVerChar , 10 ) ; } }
mxDestroyArray ( slStrMat ) ; mxDestroyArray ( slVerStructMat ) ; if ( (
status == 1 ) || ( strcmp ( slVerChar , "7.9" ) != 0 ) ) { return ; } }
ssSetOptions ( S , SS_OPTION_EXCEPTION_FREE_CODE ) ; if ( ssGetSizeofDWork (
S ) != sizeof ( D_Work_teste1 ) ) { ssSetErrorStatus ( S ,
"Unexpected error: Internal DWork sizes do "
"not match for accelerator mex file." ) ; } if ( ssGetSizeofGlobalBlockIO ( S
) != sizeof ( BlockIO_teste1 ) ) { ssSetErrorStatus ( S ,
"Unexpected error: Internal BlockIO sizes do "
"not match for accelerator mex file." ) ; } if ( ssGetSizeofY ( S ) != sizeof
( ExternalOutputs_teste1 ) ) { static char msg [ 256 ] ; sprintf ( msg ,
"Unexpected error: Internal ExternalOutputs sizes do "
"not match for accelerator mex file." ) ; } { int ssSizeofParams ;
ssGetSizeofParams ( S , & ssSizeofParams ) ; if ( ssSizeofParams != sizeof (
Parameters_teste1 ) ) { static char msg [ 256 ] ; sprintf ( msg ,
"Unexpected error: Internal Parameters sizes do "
"not match for accelerator mex file." ) ; } } _ssSetDefaultParam ( S , (
real_T * ) & teste1_rtDefaultParameters ) ; } static void
mdlInitializeSampleTimes ( SimStruct * S ) { } static void mdlTerminate (
SimStruct * S ) { }
#include "simulink.c"
