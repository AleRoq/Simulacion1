clear all
close all


%ponto de aplica��o 
uo=0.5;
vo=0.5;
rou=1025;

beta= atan2(vo,uo)



CFx = 0.2038*(beta)^2+ 0.0450*(beta)-0.6272

CFy = 0.4353*(beta)^2-1.3094*(beta)-0.0108

CFz = 0.0563*(beta)^2-0.0721 *(beta)-0.0242

%jacobiano do polinomio de segunda ordem

%ponto de aplica��o 
uo=0.5;
vo=0.5;
ro=0;
%ponto de aplica��o 
uo=0.5;
vo=0.05;
ro=0.001;

Vr=sqrt(vo^2+uo^2)

%derivada em rela��o ao u
 

CFxu= 0.2038*2*atan2(vo,uo)*(1/(1+uo^2))+0.0450*(1/(1+uo^2))*atan2(vo,uo)
CFyu= 0.4353*2*atan2(vo,uo)*(1/(1+uo^2))-1.3094*(1/(1+uo^2))*atan2(vo,uo)
CFzu= 0.0563*2*atan2(vo,uo)*(1/(1+uo^2))-0.0721*(1/(1+uo^2))*atan2(vo,uo)

%derivada em rela��o a v

CFxv= 0.2038*2*atan2(vo,uo)*(1/(1+vo^2))+0.0450*(1/(1+vo^2))*atan2(vo,uo)
CFyv= 0.4353*2*atan2(vo,uo)*(1/(1+vo^2))-1.3094*(1/(1+vo^2))*atan2(vo,uo)
CFzv= 0.0563*2*atan2(vo,uo)*(1/(1+vo^2))-0.0721*(1/(1+vo^2))*atan2(vo,uo)

%derivada em rela��o a r

CFxr= 0;
CFyr= 0;
CFzr= 0;

%matriz jacobiano
%fun��o em rela��o a u
fux = 0.5*rou*(2*uo*CFx+Vr^2*CFxu)
fuy = 0.5*rou*(2*uo*CFy+Vr^2*CFyu)
fuz = 0.5*rou*(2*uo*CFz+Vr^2*CFzu)
%fun��o em rela��o a v
fvx = 0.5*rou*(2*vo*CFy+Vr^2*CFxv)
fvy = 0.5*rou*(2*vo*CFy+Vr^2*CFyv)
fvz = 0.5*rou*(2*vo*CFz+Vr^2*CFzv)
%fun��o em real��o a r
frx =0;
fry=0;
frz=0;



arrasto = [ fux fuy fuz
            fvx fvy fvz
            frx fry frz ]
        
        
  arrasto_constante = [ -166.0267 -465.6260  -17.1047
                      -322.1047 -465.6260  -17.1047
                         0         0         0      ];







