% The file converts controller matrices from continuous to discrete
%load dataout/control3Xhinf.mat
%
Ts=0.01;
thrustermax=150;
%
ak=ak1;
bk=bk1*sy;
ck=inv(su)*ck1;
dk=inv(su)*dk1*sy;
%
sys=ss(ak,bk,ck,dk)
%sys.InputDelay = 2.7
sys_d=c2d(sys,Ts)
ak_d1=sys_d.a;
bk_d1=sys_d.b;
ck_d1=sys_d.c;
dk_d1=sys_d.d;
